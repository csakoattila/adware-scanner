package hu.csakoattila.adwarescanner.data

import android.content.Context
import androidx.core.content.edit

/** Egyszerű, app-privát beállítások (a telefonon maradnak, biztonsági mentésbe nem kerülnek). */
class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("adware_scanner", Context.MODE_PRIVATE)

    /** A szerver utolsó ETag-je – ha nem változott a lista, nem töltjük le újra. */
    var listEtag: String?
        get() = sp.getString("list_etag", null)
        set(v) = sp.edit { putString("list_etag", v) }

    /** Utolsó sikeres listafrissítés ideje (ms). */
    var lastSync: Long
        get() = sp.getLong("last_sync", 0)
        set(v) = sp.edit { putLong("last_sync", v) }

    /** Utolsó ellenőrzés ideje (ms). */
    var lastScan: Long
        get() = sp.getLong("last_scan", 0)
        set(v) = sp.edit { putLong("last_scan", v) }

    /** Utolsó teljes (napi) ellenőrzés ideje (ms). */
    var lastFullScan: Long
        get() = sp.getLong("last_full_scan", 0)
        set(v) = sp.edit { putLong("last_full_scan", v) }

    /** PackageManager.getChangedPackages() sorszáma; újraindításkor nullázódik. */
    var changeSequence: Int
        get() = sp.getInt("change_seq", 0)
        set(v) = sp.edit { putInt("change_seq", v) }

    var bootCount: Int
        get() = sp.getInt("boot_count", -1)
        set(v) = sp.edit { putInt("boot_count", v) }

    /** Az ügyfél által „nem kérek rá figyelmeztetést” jelölésű csomagok. */
    var ignored: Set<String>
        get() = sp.getStringSet("ignored", emptySet())!!.toSet()
        set(v) = sp.edit { putStringSet("ignored", v.toSet()) }

    /** Amikről már küldtünk értesítést (hogy ne ismételjük minden futáskor). */
    var notified: Set<String>
        get() = sp.getStringSet("notified", emptySet())!!.toSet()
        set(v) = sp.edit { putStringSet("notified", v.toSet()) }

    /** Már bejelentett csomagok (hogy a gomb jelezze). */
    var reported: Set<String>
        get() = sp.getStringSet("reported", emptySet())!!.toSet()
        set(v) = sp.edit { putStringSet("reported", v.toSet()) }

    /** Szervizmenü: admin token és felhasználónév. */
    var adminToken: String?
        get() = sp.getString("admin_token", null)
        set(v) = sp.edit { putString("admin_token", v) }

    var adminUser: String?
        get() = sp.getString("admin_user", null)
        set(v) = sp.edit { putString("admin_user", v) }

    var notificationAsked: Boolean
        get() = sp.getBoolean("notif_asked", false)
        set(v) = sp.edit { putBoolean("notif_asked", v) }

    // ---------------- Reklámfigyelő / reklámszűrő (v1.1) ----------------

    /** A felhasználó bekapcsolta a VPN-es reklámszűrőt (újraindítás után ebből tudjuk, kell-e indítani). */
    var vpnEnabled: Boolean
        get() = sp.getBoolean("vpn_enabled", false)
        set(v) = sp.edit { putBoolean("vpn_enabled", v) }

    /** Első bekapcsoláskor egyszer felvesszük a javasolt kizárásokat (banki appok). */
    var vpnExclusionsSeeded: Boolean
        get() = sp.getBoolean("vpn_excl_seeded", false)
        set(v) = sp.edit { putBoolean("vpn_excl_seeded", v) }

    /** A szűrésből teljesen kizárt appok. */
    var vpnExcludedApps: Set<String>
        get() = sp.getStringSet("vpn_excluded", emptySet())!!.toSet()
        set(v) = sp.edit { putStringSet("vpn_excluded", v.toSet()) }

    /** Az internettől elvágott (blokkolt) appok. */
    var blockedApps: Set<String>
        get() = sp.getStringSet("blocked_apps", emptySet())!!.toSet()
        set(v) = sp.edit { putStringSet("blocked_apps", v.toSet()) }

    /** Automatikusan (appon kívüli reklám miatt) blokkolt appok – a felületen így jelöljük. */
    var autoBlockedApps: Set<String>
        get() = sp.getStringSet("auto_blocked_apps", emptySet())!!.toSet()
        set(v) = sp.edit { putStringSet("auto_blocked_apps", v.toSet()) }

    /** Engedélyezett címek (sosem blokkoljuk, aldomainjeikkel együtt). */
    var allowedDomains: Set<String>
        get() = sp.getStringSet("allowed_domains", emptySet())!!.toSet()
        set(v) = sp.edit { putStringSet("allowed_domains", v.toSet()) }

    /** Reklám-figyelmeztetésekből elnémított appok. */
    var adMutedApps: Set<String>
        get() = sp.getStringSet("ad_muted", emptySet())!!.toSet()
        set(v) = sp.edit { putStringSet("ad_muted", v.toSet()) }

    /** Napi appon belüli reklámküszöb (teljes képernyős reklám / nap). */
    var adDailyThreshold: Int
        get() = sp.getInt("ad_threshold", 15)
        set(v) = sp.edit { putInt("ad_threshold", v) }

    /** Appon kívüli reklám esetén automatikus blokkolás (ha a VPN fut). */
    var autoBlockOutOfApp: Boolean
        get() = sp.getBoolean("auto_block", true)
        set(v) = sp.edit { putBoolean("auto_block", v) }

    /** Továbbító DNS: "system" (a hálózat saját DNS-e) vagy "adguard". */
    var upstreamDns: String
        get() = sp.getString("upstream_dns", "system")!!
        set(v) = sp.edit { putString("upstream_dns", v) }

    /** Második lista (AdGuard DNS-szűrő) bekapcsolva. */
    var useAdguardList: Boolean
        get() = sp.getBoolean("use_adguard_list", false)
        set(v) = sp.edit { putBoolean("use_adguard_list", v) }

    var weeklySummary: Boolean
        get() = sp.getBoolean("weekly_summary", true)
        set(v) = sp.edit { putBoolean("weekly_summary", v) }

    var lastWeeklySummary: Long
        get() = sp.getLong("last_weekly", 0)
        set(v) = sp.edit { putLong("last_weekly", v) }

    var lastHostsUpdate: Long
        get() = sp.getLong("last_hosts_update", 0)
        set(v) = sp.edit { putLong("last_hosts_update", v) }

    /** Az utolsó feldolgozott használati esemény ideje (ms). */
    var lastUsageEventTs: Long
        get() = sp.getLong("last_usage_ts", 0)
        set(v) = sp.edit { putLong("last_usage_ts", v) }

    /** Az utolsó előtérben lévő csomag (két futás között is kell az appon kívüli reklám felismeréséhez). */
    var lastForegroundPkg: String?
        get() = sp.getString("last_fg_pkg", null)
        set(v) = sp.edit { putString("last_fg_pkg", v) }

    /** Melyik napon (yyyy-MM-dd) melyik appra figyelmeztettünk már a napi küszöb miatt: "nap|csomag". */
    var thresholdWarned: Set<String>
        get() = sp.getStringSet("threshold_warned", emptySet())!!.toSet()
        set(v) = sp.edit { putStringSet("threshold_warned", v.toSet()) }
}
