package hu.csakoattila.adwarescanner.vpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService
import hu.csakoattila.adwarescanner.data.Prefs

/** Újraindítás vagy app-frissítés után újraindítja a reklámszűrőt, ha be volt kapcsolva. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                if (Prefs(context).vpnEnabled && VpnService.prepare(context) == null) {
                    runCatching { AdBlockVpnService.start(context) }
                }
            }
        }
    }
}
