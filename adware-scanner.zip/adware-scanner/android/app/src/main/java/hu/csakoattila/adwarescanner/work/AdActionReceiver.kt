package hu.csakoattila.adwarescanner.work

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import hu.csakoattila.adwarescanner.data.Prefs
import hu.csakoattila.adwarescanner.vpn.AdBlockVpnService

/** Az értesítések gombjai: internet elvágása, visszaállítás, elnémítás. */
class AdActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pkg = intent.getStringExtra(EXTRA_PKG) ?: return
        AdActions.apply(context, intent.action ?: return, pkg)
        Notifier.cancelAd(context, pkg)
    }

    companion object {
        const val EXTRA_PKG = "pkg"
        const val ACTION_BLOCK = "hu.csakoattila.adwarescanner.BLOCK_APP"
        const val ACTION_UNBLOCK = "hu.csakoattila.adwarescanner.UNBLOCK_APP"
        const val ACTION_MUTE = "hu.csakoattila.adwarescanner.MUTE_APP"
    }
}

/** Közös műveletek (értesítésből és a felületről is). */
object AdActions {
    fun apply(context: Context, action: String, pkg: String) {
        val prefs = Prefs(context)
        when (action) {
            AdActionReceiver.ACTION_BLOCK -> prefs.blockedApps = prefs.blockedApps + pkg
            AdActionReceiver.ACTION_UNBLOCK -> {
                prefs.blockedApps = prefs.blockedApps - pkg
                prefs.autoBlockedApps = prefs.autoBlockedApps - pkg
            }
            AdActionReceiver.ACTION_MUTE -> prefs.adMutedApps = prefs.adMutedApps + pkg
            ACTION_UNMUTE -> prefs.adMutedApps = prefs.adMutedApps - pkg
            else -> return
        }
        AdBlockVpnService.reloadIfRunning(context)
    }

    const val ACTION_UNMUTE = "hu.csakoattila.adwarescanner.UNMUTE_APP"
}
