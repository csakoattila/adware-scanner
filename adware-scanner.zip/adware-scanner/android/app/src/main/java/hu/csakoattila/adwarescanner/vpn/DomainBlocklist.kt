package hu.csakoattila.adwarescanner.vpn

import android.content.Context
import android.util.Log
import hu.csakoattila.adwarescanner.data.Prefs
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * A reklámcímek listája. Források (mindegyik összeolvad):
 *  1. assets/hosts_base.txt               – kézi alaplista, mindig
 *  2. StevenBlack: letöltött (filesDir) → vagy a fordításkor beépített (assets/hosts_stevenblack.txt)
 *  3. AdGuard DNS-szűrő (filesDir), ha be van kapcsolva – az @@ kivételeivel együtt
 *  + a felhasználó engedélyezett címei (Prefs.allowedDomains) mindig felülírják a tiltást
 */
class DomainBlocklist private constructor(
    private val blocked: Set<String>,
    private val allowed: Set<String>,
) {
    val size: Int get() = blocked.size

    fun isBlocked(domain: String?): Boolean {
        if (domain == null) return false
        if (HostsParser.matches(allowed, domain)) return false
        return HostsParser.matches(blocked, domain)
    }

    companion object {
        private const val TAG = "DomainBlocklist"
        const val STEVENBLACK_URL = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
        const val ADGUARD_URL = "https://adguardteam.github.io/AdGuardSDNSFilter/Filters/filter.txt"
        private const val FILE_STEVENBLACK = "hosts_stevenblack.txt"
        private const val FILE_ADGUARD = "hosts_adguard.txt"
        private const val MIN_VALID_DOMAINS = 1000

        /** Az összes forrás betöltése (háttérszálon hívandó). */
        fun load(context: Context): DomainBlocklist {
            val prefs = Prefs(context)
            val blocked = HashSet<String>(200_000)
            val allowed = HashSet<String>()

            readAsset(context, "hosts_base.txt") { line -> HostsParser.parseLine(line)?.let { blocked += it } }

            val sbFile = File(context.filesDir, FILE_STEVENBLACK)
            if (sbFile.exists()) {
                sbFile.forEachLine { line -> HostsParser.parseLine(line)?.let { blocked += it } }
            } else {
                readAsset(context, FILE_STEVENBLACK) { line -> HostsParser.parseLine(line)?.let { blocked += it } }
            }

            if (prefs.useAdguardList) {
                val agFile = File(context.filesDir, FILE_ADGUARD)
                if (agFile.exists()) {
                    agFile.forEachLine { line ->
                        val allow = HostsParser.parseAllowLine(line)
                        if (allow != null) allowed += allow else HostsParser.parseLine(line)?.let { blocked += it }
                    }
                }
            }

            prefs.allowedDomains.forEach { d -> HostsParser.parseLine(d)?.let { allowed += it } }
            Log.i(TAG, "Betöltve: ${blocked.size} tiltott, ${allowed.size} engedélyezett cím")
            return DomainBlocklist(blocked, allowed)
        }

        private fun readAsset(context: Context, name: String, onLine: (String) -> Unit) {
            try {
                context.assets.open(name).use { input ->
                    BufferedReader(InputStreamReader(input, Charsets.UTF_8)).forEachLine(onLine)
                }
            } catch (e: Exception) {
                // a StevenBlack-asset hiányozhat, ha a fordításkor nem volt internet
            }
        }

        /**
         * A listák letöltése közvetlenül a forrásokból. Hibás vagy túl rövid letöltés esetén a régi marad.
         * @return igaz, ha legalább egy lista frissült
         */
        fun update(context: Context): Boolean {
            val prefs = Prefs(context)
            var changed = download(context, STEVENBLACK_URL, FILE_STEVENBLACK)
            if (prefs.useAdguardList) changed = download(context, ADGUARD_URL, FILE_ADGUARD) || changed
            if (changed) prefs.lastHostsUpdate = System.currentTimeMillis()
            return changed
        }

        private fun download(context: Context, url: String, fileName: String): Boolean {
            val tmp = File(context.filesDir, "$fileName.tmp")
            val conn = URL(url).openConnection() as HttpURLConnection
            return try {
                conn.connectTimeout = 20_000
                conn.readTimeout = 60_000
                conn.setRequestProperty("User-Agent", "AdwareScanner")
                if (conn.responseCode != HttpURLConnection.HTTP_OK) return false
                conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                var valid = 0
                tmp.forEachLine { if (HostsParser.parseLine(it) != null) valid++ }
                if (valid < MIN_VALID_DOMAINS) {
                    Log.w(TAG, "$url: csak $valid cím, nem cseréljük le a régit")
                    tmp.delete()
                    false
                } else {
                    tmp.renameTo(File(context.filesDir, fileName))
                }
            } catch (e: Exception) {
                Log.w(TAG, "Letöltés sikertelen: $url", e)
                tmp.delete()
                false
            } finally {
                conn.disconnect()
            }
        }
    }
}
