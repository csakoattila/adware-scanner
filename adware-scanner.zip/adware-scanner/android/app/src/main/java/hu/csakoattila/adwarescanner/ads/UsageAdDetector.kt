package hu.csakoattila.adwarescanner.ads

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process
import hu.csakoattila.adwarescanner.data.Prefs

/** Egy észlelt teljes képernyős reklám. */
data class DetectedAd(val ts: Long, val packageName: String, val outOfApp: Boolean, val activity: String)

/**
 * Teljes képernyős reklámok felismerése a rendszer használati eseményeiből.
 *
 * Appon kívüli reklám: a reklám előtt MÁSIK app (vagy a kezdőképernyő) volt előtérben,
 * és a reklám bezárása után sem az adott app saját képernyője következik.
 * (Ha a reklám után az app saját képernyője jön, az egy indításkori reklám, tehát appon belüli.)
 */
class UsageAdDetector(private val context: Context) {
    private val prefs = Prefs(context)
    private val db = AdDb.get(context)
    private val self = context.packageName

    fun hasPermission(): Boolean = hasUsageAccess(context)

    private data class Resume(val ts: Long, val pkg: String, val cls: String, val isAd: Boolean)

    /** Feldolgozza az előző futás óta keletkezett eseményeket, elmenti és visszaadja az új reklámokat. */
    fun process(): List<DetectedAd> {
        if (!hasPermission()) return emptyList()
        val usm = context.getSystemService(UsageStatsManager::class.java) ?: return emptyList()
        val now = System.currentTimeMillis()
        val last = prefs.lastUsageEventTs
        // Első futáskor az utolsó 24 órát dolgozzuk fel, hogy rögtön legyen adat.
        val begin = if (last <= 0) now - AdDb.DAY_MS else maxOf(last + 1, now - 3 * AdDb.DAY_MS)

        val resumes = ArrayList<Resume>()
        val events = usm.queryEvents(begin, now) ?: return emptyList()
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            @Suppress("DEPRECATION")
            if (e.eventType != UsageEvents.Event.MOVE_TO_FOREGROUND) continue // = ACTIVITY_RESUMED (1)
            val pkg = e.packageName ?: continue
            val cls = e.className ?: ""
            resumes += Resume(e.timeStamp, pkg, cls, AdSignatures.isAdActivity(cls))
        }

        val found = ArrayList<DetectedAd>()
        var prevPkg: String? = prefs.lastForegroundPkg
        var prevWasAdOf: String? = null
        var prevTs = 0L
        var processedUntil = now
        var i = 0
        while (i < resumes.size) {
            val r = resumes[i]
            if (r.isAd && r.pkg != self) {
                val sameAdContinues = prevWasAdOf == r.pkg && r.ts - prevTs < 60_000
                if (!sameAdContinues) {
                    val cameFromElsewhere = prevPkg != null && prevPkg != r.pkg
                    var outOfApp = false
                    if (cameFromElsewhere) {
                        // mi jön a reklám után? (az ugyanehhez az apphoz tartozó további reklámképernyőket átugorjuk)
                        var j = i + 1
                        while (j < resumes.size && resumes[j].pkg == r.pkg && resumes[j].isAd) j++
                        if (j >= resumes.size) {
                            if (now - r.ts < 10 * 60_000) {
                                // még nem tudjuk eldönteni: a következő futás újra feldolgozza innen
                                processedUntil = r.ts - 1
                                break
                            }
                            outOfApp = true // 10 perce nincs semmi utána: a felhasználó otthagyta
                        } else {
                            outOfApp = resumes[j].pkg != r.pkg
                        }
                    }
                    val ad = DetectedAd(r.ts, r.pkg, outOfApp, r.cls)
                    db.addFullscreenAd(ad.ts, ad.packageName, ad.outOfApp, ad.activity)
                    found += ad
                }
                prevWasAdOf = r.pkg
            } else {
                prevWasAdOf = null
            }
            prevPkg = r.pkg
            prevTs = r.ts
            i++
        }

        // Ha félbehagytuk (eldöntetlen reklám), az előtérben lévő app a reklám előtti marad.
        prefs.lastForegroundPkg = if (processedUntil < now) {
            resumes.lastOrNull { it.ts <= processedUntil }?.pkg ?: prefs.lastForegroundPkg
        } else {
            resumes.lastOrNull()?.pkg ?: prefs.lastForegroundPkg
        }
        prefs.lastUsageEventTs = processedUntil
        return found
    }

    companion object {
        fun hasUsageAccess(context: Context): Boolean {
            val ops = context.getSystemService(AppOpsManager::class.java) ?: return false
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
            } else {
                @Suppress("DEPRECATION")
                ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
            }
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }
}
