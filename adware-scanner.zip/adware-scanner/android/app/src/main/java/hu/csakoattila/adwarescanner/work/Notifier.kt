package hu.csakoattila.adwarescanner.work

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import hu.csakoattila.adwarescanner.R
import hu.csakoattila.adwarescanner.data.Threat
import hu.csakoattila.adwarescanner.ui.MainActivity
import hu.csakoattila.adwarescanner.vpn.AdBlockVpnService

object Notifier {
    const val CHANNEL_THREATS = "threats"
    const val CHANNEL_ADS = "ads"
    const val CHANNEL_VPN = "vpn"
    private const val SUMMARY_ID = 1
    private const val VPN_ID = 9001
    private const val VPN_STOPPED_ID = 9002
    private const val WEEKLY_ID = 9003

    fun createChannels(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(
            CHANNEL_THREATS,
            context.getString(R.string.channel_threats),
            NotificationManager.IMPORTANCE_HIGH,
        ).apply { description = context.getString(R.string.channel_threats_desc) }
        nm.createNotificationChannel(ch)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ADS, "Reklámos alkalmazások", NotificationManager.IMPORTANCE_HIGH)
                .apply { description = "Ha egy app túl sok reklámot mutat, vagy más app használata közben jelenít meg reklámot" },
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_VPN, "Reklámszűrő állapota", NotificationManager.IMPORTANCE_LOW)
                .apply { description = "Állandó értesítés, amíg a reklámszűrő fut"; setShowBadge(false) },
        )
    }

    private fun canNotify(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun openAppIntent(context: Context): PendingIntent =
        PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    /** Egy új, tiltólistás app értesítése „Törlés” gombbal. */
    fun notifyThreat(context: Context, t: Threat) {
        if (!canNotify(context)) return
        val id = t.app.packageName.hashCode()
        val uninstall = PendingIntent.getActivity(
            context, id,
            Intent(Intent.ACTION_DELETE, Uri.parse("package:" + t.app.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val risk = if (t.entry.isHighRisk) "Magas kockázat" else "Közepes kockázat"
        val n = NotificationCompat.Builder(context, CHANNEL_THREATS)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setColor(0xFFB3261E.toInt())
            .setContentTitle("Tiltott alkalmazás: ${t.app.label}")
            .setContentText("$risk – ${t.entry.reason}")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$risk\n${t.entry.reason}\n\nCsomag: ${t.app.packageName}"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openAppIntent(context))
            .addAction(0, "Törlés", uninstall)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    /** Napi összesítő, ha még mindig van tiltott app a telefonon. */
    fun notifySummary(context: Context, count: Int) {
        if (!canNotify(context) || count <= 0) return
        val n = NotificationCompat.Builder(context, CHANNEL_THREATS)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setColor(0xFFB3261E.toInt())
            .setContentTitle("$count tiltott alkalmazás van a telefonon")
            .setContentText("Koppints ide az áttekintéshez és az eltávolításhoz.")
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(SUMMARY_ID, n)
        } catch (_: SecurityException) {
        }
    }

    fun cancel(context: Context, packageName: String) {
        NotificationManagerCompat.from(context).cancel(packageName.hashCode())
    }

    // ---------------- Reklámfigyelő / reklámszűrő ----------------

    private fun adNotifId(pkg: String) = ("ad:" + pkg).hashCode()

    private fun adAction(context: Context, action: String, pkg: String): PendingIntent =
        PendingIntent.getBroadcast(
            context, (action + pkg).hashCode(),
            Intent(context, AdActionReceiver::class.java).setAction(action).putExtra(AdActionReceiver.EXTRA_PKG, pkg),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    private fun uninstallIntent(context: Context, pkg: String): PendingIntent =
        PendingIntent.getActivity(
            context, ("del:" + pkg).hashCode(),
            Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    private fun post(context: Context, id: Int, n: android.app.Notification) {
        if (!canNotify(context)) return
        try {
            NotificationManagerCompat.from(context).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    /** Appon kívül megjelenő reklám – azonnali értesítés (ha blokkoltuk, Visszaállítás gombbal). */
    fun notifyOutOfAppAd(context: Context, pkg: String, label: String, blocked: Boolean, count: Int) {
        val text = if (blocked) {
            "Reklámot jelenített meg, miközben nem használtad ($count×). Elvágtuk az internetét, így nem tud több reklámot letölteni."
        } else {
            "Reklámot jelenített meg, miközben nem használtad ($count×). Ez kéretlen reklámprogramra (adware) utal."
        }
        val b = NotificationCompat.Builder(context, CHANNEL_ADS)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setColor(0xFFB3261E.toInt())
            .setContentTitle(if (blocked) "Blokkolva: $label" else "Reklámos alkalmazás: $label")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
        if (blocked) {
            b.addAction(0, "Visszaállítás", adAction(context, AdActionReceiver.ACTION_UNBLOCK, pkg))
        } else if (AdBlockVpnService.isActive) {
            b.addAction(0, "Internet elvágása", adAction(context, AdActionReceiver.ACTION_BLOCK, pkg))
        }
        b.addAction(0, "Törlés", uninstallIntent(context, pkg))
        post(context, adNotifId(pkg), b.build())
    }

    /** Napi küszöb feletti appon belüli reklámok. */
    fun notifyAdThreshold(context: Context, pkg: String, label: String, count: Int) {
        val text = "Ma $count teljes képernyős reklámot mutatott. Ha zavar, elvághatod az internetét vagy törölheted."
        val b = NotificationCompat.Builder(context, CHANNEL_ADS)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setColor(0xFFC77700.toInt())
            .setContentTitle("Sok reklám: $label")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
        if (AdBlockVpnService.isActive) {
            b.addAction(0, "Internet elvágása", adAction(context, AdActionReceiver.ACTION_BLOCK, pkg))
        }
        b.addAction(0, "Nem érdekel", adAction(context, AdActionReceiver.ACTION_MUTE, pkg))
        post(context, adNotifId(pkg), b.build())
    }

    fun cancelAd(context: Context, pkg: String) {
        NotificationManagerCompat.from(context).cancel(adNotifId(pkg))
    }

    /** Heti összesítő. */
    fun notifyWeekly(context: Context, blocked: Int, fullscreen: Int, topLabel: String?, topCount: Int) {
        val sb = StringBuilder()
        if (blocked > 0) sb.append("A héten $blocked reklámot blokkoltunk. ")
        if (fullscreen > 0) sb.append("$fullscreen teljes képernyős reklám jelent meg. ")
        if (topLabel != null && topCount > 0) sb.append("A legreklámosabb app: $topLabel ($topCount).")
        if (sb.isEmpty()) return
        val n = NotificationCompat.Builder(context, CHANNEL_ADS)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setColor(0xFF0B6B3A.toInt())
            .setContentTitle("Heti reklám-összesítő")
            .setContentText(sb.toString().trim())
            .setStyle(NotificationCompat.BigTextStyle().bigText(sb.toString().trim()))
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .build()
        post(context, WEEKLY_ID, n)
    }

    /** Állandó értesítés, amíg a reklámszűrő fut. */
    fun updateVpnNotification(context: Context, blockedToday: Int, blockedApps: Int) {
        val stop = PendingIntent.getService(
            context, 1,
            Intent(context, AdBlockVpnService::class.java).setAction(AdBlockVpnService.ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val extra = if (blockedApps > 0) " · $blockedApps app blokkolva" else ""
        val n = NotificationCompat.Builder(context, CHANNEL_VPN)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setColor(0xFF0B6B3A.toInt())
            .setContentTitle("Reklámszűrés aktív")
            .setContentText("Ma $blockedToday reklám blokkolva$extra")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent(context))
            .addAction(0, "Kikapcsolás", stop)
            .build()
        post(context, VPN_ID, n)
    }

    fun cancelVpnNotification(context: Context) {
        NotificationManagerCompat.from(context).cancel(VPN_ID)
    }

    fun notifyVpnStopped(context: Context) {
        val n = NotificationCompat.Builder(context, CHANNEL_ADS)
            .setSmallIcon(R.drawable.ic_stat_shield)
            .setContentTitle("A reklámszűrő leállt")
            .setContentText("Másik VPN indult, vagy a kapcsolatot a beállításokban bontották. Az appban újra bekapcsolhatod.")
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .build()
        post(context, VPN_STOPPED_ID, n)
    }
}
