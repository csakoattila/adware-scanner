package hu.csakoattila.adwarescanner.vpn;

import java.util.Locale;

/**
 * IPv4/UDP DNS-csomagok feldolgozása és válaszcsomagok építése a VPN-szűrőhöz.
 * Tiszta Java, Android-függőség nélkül, hogy egységtesztelhető legyen.
 */
public final class DnsPacket {

    private DnsPacket() {}

    /** Egy beolvasott DNS-kérés. */
    public static final class Query {
        public final byte[] srcIp;    // 4 bájt
        public final byte[] dstIp;    // 4 bájt
        public final int srcPort;
        public final int dstPort;
        public final byte[] dns;      // a DNS-üzenet (UDP payload)
        public final String name;     // a kérdezett név kisbetűvel, pont nélkül a végén; null, ha nem olvasható
        public final int qtype;

        Query(byte[] srcIp, byte[] dstIp, int srcPort, int dstPort, byte[] dns, String name, int qtype) {
            this.srcIp = srcIp;
            this.dstIp = dstIp;
            this.srcPort = srcPort;
            this.dstPort = dstPort;
            this.dns = dns;
            this.name = name;
            this.qtype = qtype;
        }
    }

    /** IPv4 + UDP + 53-as port esetén a kérés, minden másra null. */
    public static Query parse(byte[] p, int len) {
        if (len < 20 + 8 + 12) return null;
        int version = (p[0] >> 4) & 0xF;
        if (version != 4) return null;
        int ihl = (p[0] & 0xF) * 4;
        if (ihl < 20 || len < ihl + 8 + 12) return null;
        int totalLen = u16(p, 2);
        if (totalLen > len || totalLen < ihl + 8) totalLen = len;
        int proto = p[9] & 0xFF;
        if (proto != 17) return null; // UDP
        // töredezett csomag nem DNS-kérés
        int flagsFrag = u16(p, 6);
        if ((flagsFrag & 0x1FFF) != 0 || (flagsFrag & 0x2000) != 0) return null;

        byte[] src = slice(p, 12, 4);
        byte[] dst = slice(p, 16, 4);
        int srcPort = u16(p, ihl);
        int dstPort = u16(p, ihl + 2);
        if (dstPort != 53) return null;
        int udpLen = u16(p, ihl + 4);
        int payloadLen = Math.min(udpLen - 8, totalLen - ihl - 8);
        if (payloadLen < 12) return null;
        byte[] dns = slice(p, ihl + 8, payloadLen);

        String name = null;
        int qtype = 0;
        int qd = u16(dns, 4);
        if (qd >= 1) {
            StringBuilder sb = new StringBuilder();
            int off = readName(dns, 12, sb);
            if (off > 0 && off + 4 <= dns.length) {
                name = sb.toString().toLowerCase(Locale.ROOT);
                qtype = u16(dns, off);
            }
        }
        return new Query(src, dst, srcPort, dstPort, dns, name, qtype);
    }

    /**
     * A kérdés-szakasz végének eltolása (a név + QTYPE + QCLASS után), vagy -1.
     */
    public static int questionEnd(byte[] dns) {
        if (dns.length < 12 || u16(dns, 4) < 1) return -1;
        int off = readName(dns, 12, null);
        if (off < 0 || off + 4 > dns.length) return -1;
        return off + 4;
    }

    /** „Nem létezik” (NXDOMAIN) válasz a kérésre: csak a fejléc és a kérdés marad. */
    public static byte[] nxdomain(byte[] query) {
        int end = questionEnd(query);
        if (end < 0) end = Math.min(query.length, 12);
        byte[] r = slice(query, 0, end);
        int flags = u16(query, 2);
        int opcodeRd = flags & 0x7900;            // OPCODE + RD megtartása
        int resp = 0x8000 | opcodeRd | 0x0080 | 3; // QR=1, RA=1, RCODE=3
        put16(r, 2, resp);
        put16(r, 4, end > 12 ? 1 : 0); // QDCOUNT
        put16(r, 6, 0);                // ANCOUNT
        put16(r, 8, 0);                // NSCOUNT
        put16(r, 10, 0);               // ARCOUNT
        return r;
    }

    /** IPv4/UDP válaszcsomag a kérés feladójának: forrás = a virtuális DNS-szerver, 53-as port. */
    public static byte[] buildResponse(Query q, byte[] dnsPayload) {
        int total = 20 + 8 + dnsPayload.length;
        byte[] out = new byte[total];
        out[0] = 0x45;                 // IPv4, IHL=5
        put16(out, 2, total);
        put16(out, 4, 0);              // azonosító
        put16(out, 6, 0x4000);         // DF
        out[8] = 64;                   // TTL
        out[9] = 17;                   // UDP
        System.arraycopy(q.dstIp, 0, out, 12, 4);
        System.arraycopy(q.srcIp, 0, out, 16, 4);
        put16(out, 10, ipChecksum(out, 0, 20));

        put16(out, 20, q.dstPort);     // 53
        put16(out, 22, q.srcPort);
        put16(out, 24, 8 + dnsPayload.length);
        put16(out, 26, 0);             // UDP-ellenőrzőösszeg IPv4-en elhagyható
        System.arraycopy(dnsPayload, 0, out, 28, dnsPayload.length);
        return out;
    }

    // ------------------------------------------------------------------

    /** Név beolvasása (tömörítési mutatót is kezel). Visszaadja a név utáni eltolást, hibánál -1. */
    static int readName(byte[] d, int off, StringBuilder sb) {
        int pos = off;
        int end = -1;
        int jumps = 0;
        while (true) {
            if (pos >= d.length) return -1;
            int len = d[pos] & 0xFF;
            if (len == 0) {
                pos++;
                break;
            }
            if ((len & 0xC0) == 0xC0) {
                if (pos + 1 >= d.length || ++jumps > 10) return -1;
                if (end < 0) end = pos + 2;
                pos = ((len & 0x3F) << 8) | (d[pos + 1] & 0xFF);
                continue;
            }
            if (len > 63 || pos + 1 + len > d.length) return -1;
            if (sb != null) {
                if (sb.length() > 0) sb.append('.');
                for (int i = 0; i < len; i++) sb.append((char) (d[pos + 1 + i] & 0xFF));
            }
            pos += 1 + len;
        }
        return end >= 0 ? end : pos;
    }

    static int ipChecksum(byte[] b, int off, int len) {
        int sum = 0;
        for (int i = off; i < off + len; i += 2) {
            sum += ((b[i] & 0xFF) << 8) | (i + 1 < off + len ? (b[i + 1] & 0xFF) : 0);
        }
        while ((sum >> 16) != 0) sum = (sum & 0xFFFF) + (sum >> 16);
        return ~sum & 0xFFFF;
    }

    static int u16(byte[] b, int off) {
        return ((b[off] & 0xFF) << 8) | (b[off + 1] & 0xFF);
    }

    static void put16(byte[] b, int off, int v) {
        b[off] = (byte) (v >> 8);
        b[off + 1] = (byte) v;
    }

    static byte[] slice(byte[] b, int off, int len) {
        byte[] r = new byte[len];
        System.arraycopy(b, off, r, 0, len);
        return r;
    }
}
