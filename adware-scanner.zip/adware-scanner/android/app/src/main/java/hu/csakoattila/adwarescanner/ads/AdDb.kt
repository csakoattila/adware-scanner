package hu.csakoattila.adwarescanner.ads

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Egy app reklámstatisztikája egy időszakra. */
data class AdStat(
    val packageName: String,
    val fullscreenInApp: Int,
    val fullscreenOutOfApp: Int,
    val dnsBlocked: Int,
) {
    val fullscreenTotal: Int get() = fullscreenInApp + fullscreenOutOfApp
    /** Rangsoroláshoz: az appon kívüli reklám a legsúlyosabb. */
    val score: Int get() = fullscreenOutOfApp * 20 + fullscreenInApp * 3 + dnsBlocked / 10
}

data class AdEvent(val ts: Long, val packageName: String, val outOfApp: Boolean, val activity: String)

data class BlockedDomain(val ts: Long, val packageName: String, val domain: String)

/**
 * Helyi reklám-adatbázis. Semmi nem kerül belőle a szerverre.
 *  - fs_events:  teljes képernyős reklámok egyenként (30 napig)
 *  - fs_daily:   napi összesítő appokra (1 évig)
 *  - dns_daily:  blokkolt reklámcímek száma naponta, appokra (1 évig; "" = ismeretlen app)
 *  - dns_recent: legutóbb blokkolt címek (utolsó 300)
 */
class AdDb private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "ads.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE fs_events (ts INTEGER NOT NULL, pkg TEXT NOT NULL, out_of_app INTEGER NOT NULL, activity TEXT NOT NULL)")
        db.execSQL("CREATE INDEX idx_fs_pkg ON fs_events (pkg, ts)")
        db.execSQL("CREATE TABLE fs_daily (day TEXT NOT NULL, pkg TEXT NOT NULL, in_app INTEGER NOT NULL DEFAULT 0, out_app INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (day, pkg))")
        db.execSQL("CREATE TABLE dns_daily (day TEXT NOT NULL, pkg TEXT NOT NULL, blocked INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (day, pkg))")
        db.execSQL("CREATE TABLE dns_recent (ts INTEGER NOT NULL, pkg TEXT NOT NULL, domain TEXT NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // ---------------- írás ----------------

    fun addFullscreenAd(ts: Long, pkg: String, outOfApp: Boolean, activity: String) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.insert("fs_events", null, ContentValues().apply {
                put("ts", ts); put("pkg", pkg); put("out_of_app", if (outOfApp) 1 else 0); put("activity", activity)
            })
            val d = day(ts)
            db.execSQL("INSERT OR IGNORE INTO fs_daily (day, pkg) VALUES (?, ?)", arrayOf(d, pkg))
            val col = if (outOfApp) "out_app" else "in_app"
            db.execSQL("UPDATE fs_daily SET $col = $col + 1 WHERE day = ? AND pkg = ?", arrayOf(d, pkg))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** A VPN-szolgáltatás gyűjtve, félpercenként írja ki a számlálókat. */
    fun addDnsBlocked(counts: Map<String, Int>, recent: List<BlockedDomain>) {
        if (counts.isEmpty() && recent.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            val d = day(System.currentTimeMillis())
            for ((pkg, n) in counts) {
                db.execSQL("INSERT OR IGNORE INTO dns_daily (day, pkg) VALUES (?, ?)", arrayOf(d, pkg))
                db.execSQL("UPDATE dns_daily SET blocked = blocked + ? WHERE day = ? AND pkg = ?", arrayOf<Any>(n, d, pkg))
            }
            for (r in recent) {
                db.insert("dns_recent", null, ContentValues().apply {
                    put("ts", r.ts); put("pkg", r.packageName); put("domain", r.domain)
                })
            }
            db.execSQL("DELETE FROM dns_recent WHERE rowid NOT IN (SELECT rowid FROM dns_recent ORDER BY ts DESC LIMIT 300)")
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Régi adatok törlése: események 30 nap, összesítők 1 év. */
    fun cleanup() {
        val db = writableDatabase
        val now = System.currentTimeMillis()
        db.delete("fs_events", "ts < ?", arrayOf((now - 30L * DAY_MS).toString()))
        val yearAgo = day(now - 365L * DAY_MS)
        db.delete("fs_daily", "day < ?", arrayOf(yearAgo))
        db.delete("dns_daily", "day < ?", arrayOf(yearAgo))
    }

    // ---------------- olvasás ----------------

    /** Appok statisztikája az utolsó [days] napra (1 = csak ma). */
    fun stats(days: Int): List<AdStat> {
        val since = day(startOfToday() - (days - 1L) * DAY_MS)
        val map = HashMap<String, IntArray>() // in, out, dns
        readableDatabase.rawQuery(
            "SELECT pkg, SUM(in_app), SUM(out_app) FROM fs_daily WHERE day >= ? GROUP BY pkg", arrayOf(since),
        ).use { c ->
            while (c.moveToNext()) {
                val a = map.getOrPut(c.getString(0)) { IntArray(3) }
                a[0] += c.getInt(1); a[1] += c.getInt(2)
            }
        }
        readableDatabase.rawQuery(
            "SELECT pkg, SUM(blocked) FROM dns_daily WHERE day >= ? AND pkg <> '' GROUP BY pkg", arrayOf(since),
        ).use { c ->
            while (c.moveToNext()) {
                map.getOrPut(c.getString(0)) { IntArray(3) }[2] += c.getInt(1)
            }
        }
        return map.map { (p, a) -> AdStat(p, a[0], a[1], a[2]) }.sortedByDescending { it.score }
    }

    /** Összes blokkolt reklámcím az utolsó [days] napban (ismeretlen appokkal együtt). */
    fun totalDnsBlocked(days: Int): Int {
        val since = day(startOfToday() - (days - 1L) * DAY_MS)
        readableDatabase.rawQuery("SELECT COALESCE(SUM(blocked), 0) FROM dns_daily WHERE day >= ?", arrayOf(since)).use { c ->
            return if (c.moveToFirst()) c.getInt(0) else 0
        }
    }

    fun totalFullscreen(days: Int): Pair<Int, Int> {
        val since = day(startOfToday() - (days - 1L) * DAY_MS)
        readableDatabase.rawQuery(
            "SELECT COALESCE(SUM(in_app), 0), COALESCE(SUM(out_app), 0) FROM fs_daily WHERE day >= ?", arrayOf(since),
        ).use { c ->
            return if (c.moveToFirst()) c.getInt(0) to c.getInt(1) else 0 to 0
        }
    }

    /** Egy app mai appon belüli reklámjainak száma (a napi küszöbhöz). */
    fun todayInApp(pkg: String): Int {
        readableDatabase.rawQuery(
            "SELECT in_app FROM fs_daily WHERE day = ? AND pkg = ?", arrayOf(day(System.currentTimeMillis()), pkg),
        ).use { c -> return if (c.moveToFirst()) c.getInt(0) else 0 }
    }

    fun recentEvents(pkg: String, limit: Int = 30): List<AdEvent> {
        val out = ArrayList<AdEvent>()
        readableDatabase.rawQuery(
            "SELECT ts, pkg, out_of_app, activity FROM fs_events WHERE pkg = ? ORDER BY ts DESC LIMIT $limit", arrayOf(pkg),
        ).use { c ->
            while (c.moveToNext()) out += AdEvent(c.getLong(0), c.getString(1), c.getInt(2) == 1, c.getString(3))
        }
        return out
    }

    fun recentDomains(limit: Int = 100, pkg: String? = null): List<BlockedDomain> {
        val out = ArrayList<BlockedDomain>()
        val where = if (pkg != null) "WHERE pkg = ?" else ""
        val args: Array<String> = if (pkg != null) arrayOf(pkg) else emptyArray()
        readableDatabase.rawQuery("SELECT ts, pkg, domain FROM dns_recent $where ORDER BY ts DESC LIMIT $limit", args).use { c ->
            while (c.moveToNext()) out += BlockedDomain(c.getLong(0), c.getString(1), c.getString(2))
        }
        return out
    }

    companion object {
        const val DAY_MS = 86_400_000L

        @Volatile
        private var instance: AdDb? = null

        fun get(context: Context): AdDb =
            instance ?: synchronized(this) { instance ?: AdDb(context).also { instance = it } }

        private val dayFmt = object : ThreadLocal<SimpleDateFormat>() {
            override fun initialValue() = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        }

        fun day(ts: Long): String = dayFmt.get()!!.format(Date(ts))

        fun startOfToday(): Long = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
}
