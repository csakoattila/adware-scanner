package hu.csakoattila.adwarescanner.ads

import android.content.Context
import hu.csakoattila.adwarescanner.data.AppInventory
import hu.csakoattila.adwarescanner.data.Prefs
import hu.csakoattila.adwarescanner.vpn.AdBlockVpnService
import hu.csakoattila.adwarescanner.work.Notifier

/** A reklámfigyelő döntési logikája: appon kívüli reklám → értesítés/blokk, napi küszöb → figyelmeztetés. */
object AdMonitor {
    /**
     * Feldolgozza az új reklámeseményeket, értesít, és ha kell, blokkol.
     * A háttérellenőrzés és a felület is ezt hívja (egyszerre csak egy futhat).
     * @return az új reklámok száma
     */
    @Synchronized
    fun process(ctx: Context, inventory: AppInventory = AppInventory(ctx)): Int {
        val prefs = Prefs(ctx)
        val ads = UsageAdDetector(ctx).process()
        if (ads.isEmpty()) return 0
        val db = AdDb.get(ctx)
        val muted = prefs.adMutedApps

        // a) Appon kívüli reklám → azonnali értesítés, ha a szűrő fut: automatikus blokkolás
        var blockedSomething = false
        for ((pkg, list) in ads.filter { it.outOfApp }.groupBy { it.packageName }) {
            if (pkg in muted) continue
            val app = inventory.find(pkg) ?: continue
            val canBlock = AdBlockVpnService.isActive && prefs.autoBlockOutOfApp &&
                !app.isSystem && pkg !in prefs.vpnExcludedApps
            if (pkg in prefs.blockedApps) continue // már blokkolva, nem zaklatjuk újra
            if (canBlock) {
                prefs.blockedApps = prefs.blockedApps + pkg
                prefs.autoBlockedApps = prefs.autoBlockedApps + pkg
                blockedSomething = true
            }
            Notifier.notifyOutOfAppAd(ctx, pkg, app.label, canBlock, list.size)
        }
        if (blockedSomething) AdBlockVpnService.reloadIfRunning(ctx)

        // b) Appon belüli reklámok napi küszöbe → naponta egyszer figyelmeztetés
        val today = AdDb.day(System.currentTimeMillis())
        val warned = prefs.thresholdWarned.filter { it.startsWith("$today|") }.toMutableSet()
        for (pkg in ads.filter { !it.outOfApp }.map { it.packageName }.distinct()) {
            if (pkg in muted || pkg in prefs.blockedApps) continue
            val key = "$today|$pkg"
            if (key in warned) continue
            val n = db.todayInApp(pkg)
            if (n >= prefs.adDailyThreshold) {
                val app = inventory.find(pkg) ?: continue
                Notifier.notifyAdThreshold(ctx, pkg, app.label, n)
                warned += key
            }
        }
        prefs.thresholdWarned = warned
        return ads.size
    }
}
