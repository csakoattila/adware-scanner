package hu.csakoattila.adwarescanner.ui

import android.app.Application
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import hu.csakoattila.adwarescanner.ads.AdDb
import hu.csakoattila.adwarescanner.ads.AdEvent
import hu.csakoattila.adwarescanner.ads.AdMonitor
import hu.csakoattila.adwarescanner.ads.AdStat
import hu.csakoattila.adwarescanner.ads.AdTools
import hu.csakoattila.adwarescanner.ads.BlockedDomain
import hu.csakoattila.adwarescanner.ads.UsageAdDetector
import hu.csakoattila.adwarescanner.data.AppInventory
import hu.csakoattila.adwarescanner.data.InstalledApp
import hu.csakoattila.adwarescanner.data.Prefs
import hu.csakoattila.adwarescanner.vpn.AdBlockVpnService
import hu.csakoattila.adwarescanner.vpn.DomainBlocklist
import hu.csakoattila.adwarescanner.vpn.HostsParser
import hu.csakoattila.adwarescanner.work.AdActionReceiver
import hu.csakoattila.adwarescanner.work.AdActions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Egy sor az appok reklám-rangsorában. */
data class AdAppRow(
    val packageName: String,
    val label: String,
    val stat: AdStat,
    val blocked: Boolean,
    val autoBlocked: Boolean,
    val overlay: Boolean,
    val muted: Boolean,
    val isSystem: Boolean,
)

data class AdDetails(
    val row: AdAppRow,
    val events: List<AdEvent>,
    val domains: List<BlockedDomain>,
)

data class AdsState(
    val loading: Boolean = true,
    val vpnOn: Boolean = false,
    val blockedToday: Int = 0,
    val fsInToday: Int = 0,
    val fsOutToday: Int = 0,
    val period: Int = 1,
    val rows: List<AdAppRow> = emptyList(),
    val usageAccess: Boolean = false,
    val privateDnsStrict: Boolean = false,
    val perAppSupported: Boolean = Build.VERSION.SDK_INT >= 29,
    // beállítások
    val threshold: Int = 15,
    val autoBlock: Boolean = true,
    val weekly: Boolean = true,
    val upstream: String = "system",
    val adguardList: Boolean = false,
    val excluded: Set<String> = emptySet(),
    val allowed: Set<String> = emptySet(),
    val recentDomains: List<BlockedDomain> = emptyList(),
    val lastHostsUpdate: Long = 0,
    val updatingLists: Boolean = false,
    val userApps: List<InstalledApp> = emptyList(),
    val details: AdDetails? = null,
    val message: String? = null,
)

class AdsViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application get() = getApplication()
    private val prefs = Prefs(app)
    private val db = AdDb.get(app)
    private val inventory = AppInventory(app)

    private val _state = MutableStateFlow(AdsState())
    val state: StateFlow<AdsState> = _state.asStateFlow()

    private var labels: Map<String, InstalledApp> = emptyMap()

    init {
        refresh()
        // a kapcsoló és a mai szám élőben frissüljön, amíg a képernyő látszik
        viewModelScope.launch {
            while (true) {
                delay(5_000)
                _state.update {
                    it.copy(
                        vpnOn = AdBlockVpnService.isActive,
                        blockedToday = if (AdBlockVpnService.isActive) AdBlockVpnService.liveBlockedToday.get() else it.blockedToday,
                    )
                }
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            val data = withContext(Dispatchers.Default) {
                val apps = inventory.all()
                labels = apps.associateBy { it.packageName }
                // új reklámesemények feldolgozása (ugyanaz a logika, mint a háttérben – értesítéssel, blokkal)
                runCatching { AdMonitor.process(ctx, inventory) }
                load(apps)
            }
            _state.value = data.copy(period = _state.value.period, details = _state.value.details, message = _state.value.message)
        }
    }

    private fun load(apps: List<InstalledApp>, period: Int = _state.value.period): AdsState {
        val stats = db.stats(period).associateBy { it.packageName }.toMutableMap()
        val blocked = prefs.blockedApps
        val auto = prefs.autoBlockedApps
        val muted = prefs.adMutedApps
        // a blokkolt appok akkor is látszódjanak, ha az időszakban nem volt reklámjuk
        for (p in blocked) stats.getOrPut(p) { AdStat(p, 0, 0, 0) }
        val rows = stats.values
            .filter { it.fullscreenTotal > 0 || it.dnsBlocked > 0 || it.packageName in blocked }
            .map { st ->
                val a = labels[st.packageName]
                AdAppRow(
                    packageName = st.packageName,
                    label = a?.label ?: st.packageName,
                    stat = st,
                    blocked = st.packageName in blocked,
                    autoBlocked = st.packageName in auto,
                    overlay = AdTools.canDrawOverlays(ctx, st.packageName),
                    muted = st.packageName in muted,
                    isSystem = a?.isSystem ?: false,
                )
            }
            .sortedWith(compareByDescending<AdAppRow> { it.blocked }.thenByDescending { it.stat.score })
        val (fin, fout) = db.totalFullscreen(1)
        return AdsState(
            loading = false,
            vpnOn = AdBlockVpnService.isActive,
            blockedToday = if (AdBlockVpnService.isActive) AdBlockVpnService.liveBlockedToday.get() else db.totalDnsBlocked(1),
            fsInToday = fin,
            fsOutToday = fout,
            period = period,
            rows = rows,
            usageAccess = UsageAdDetector.hasUsageAccess(ctx),
            privateDnsStrict = AdTools.isPrivateDnsStrict(ctx),
            threshold = prefs.adDailyThreshold,
            autoBlock = prefs.autoBlockOutOfApp,
            weekly = prefs.weeklySummary,
            upstream = prefs.upstreamDns,
            adguardList = prefs.useAdguardList,
            excluded = prefs.vpnExcludedApps,
            allowed = prefs.allowedDomains,
            recentDomains = db.recentDomains(100),
            lastHostsUpdate = prefs.lastHostsUpdate,
            userApps = apps.filter { !it.isSystem },
        )
    }

    fun setPeriod(days: Int) {
        viewModelScope.launch {
            val apps = labels.values.toList()
            val s = withContext(Dispatchers.Default) { load(if (apps.isEmpty()) inventory.all() else apps, days) }
            _state.value = s.copy(details = _state.value.details, message = _state.value.message)
        }
    }

    // ---------------- VPN ----------------

    /** Az Activity hívja, miután a rendszer VPN-engedélyét megadták (vagy már meg volt). */
    fun startVpn() {
        if (!prefs.vpnExclusionsSeeded) {
            prefs.vpnExcludedApps = prefs.vpnExcludedApps + AdTools.suggestedExclusions(inventory.all())
            prefs.vpnExclusionsSeeded = true
        }
        AdBlockVpnService.start(ctx)
        prefs.vpnEnabled = true
        viewModelScope.launch {
            delay(1_000)
            refresh()
        }
    }

    fun stopVpn() {
        AdBlockVpnService.stop(ctx)
        prefs.vpnEnabled = false
        viewModelScope.launch {
            delay(800)
            refresh()
        }
    }

    // ---------------- app-műveletek ----------------

    fun block(pkg: String) = act(AdActionReceiver.ACTION_BLOCK, pkg, "Internet elvágva.")
    fun unblock(pkg: String) = act(AdActionReceiver.ACTION_UNBLOCK, pkg, "Internet visszaállítva.")
    fun mute(pkg: String) = act(AdActionReceiver.ACTION_MUTE, pkg, "Erről az appról nem kérsz több figyelmeztetést.")
    fun unmute(pkg: String) = act(AdActions.ACTION_UNMUTE, pkg, "Figyelmeztetések visszakapcsolva.")

    private fun act(action: String, pkg: String, msg: String) {
        AdActions.apply(ctx, action, pkg)
        _state.update { it.copy(message = msg) }
        refreshKeepDetails(pkg)
    }

    private fun refreshKeepDetails(pkg: String) {
        viewModelScope.launch {
            val s = withContext(Dispatchers.Default) { load(labels.values.toList()) }
            val details = _state.value.details?.let { d ->
                s.rows.firstOrNull { it.packageName == pkg }?.let { d.copy(row = it) } ?: d
            }
            _state.value = s.copy(details = details, message = _state.value.message)
        }
    }

    fun openDetails(row: AdAppRow) {
        viewModelScope.launch {
            val d = withContext(Dispatchers.Default) {
                AdDetails(row, db.recentEvents(row.packageName, 30), db.recentDomains(30, row.packageName))
            }
            _state.update { it.copy(details = d) }
        }
    }

    fun closeDetails() = _state.update { it.copy(details = null) }

    /** A bejelentéshez automatikusan kitöltött megjegyzés. */
    fun reportNote(row: AdAppRow): String {
        val s7 = db.stats(7).firstOrNull { it.packageName == row.packageName }
        val n = s7 ?: row.stat
        return "Reklámfigyelő (7 nap): ${n.fullscreenTotal} teljes képernyős reklám, ebből ${n.fullscreenOutOfApp} appon kívül; " +
            "${n.dnsBlocked} blokkolt reklámcím."
    }

    // ---------------- beállítások ----------------

    fun setThreshold(v: Int) { prefs.adDailyThreshold = v; _state.update { it.copy(threshold = v) } }
    fun setAutoBlock(v: Boolean) { prefs.autoBlockOutOfApp = v; _state.update { it.copy(autoBlock = v) } }
    fun setWeekly(v: Boolean) { prefs.weeklySummary = v; _state.update { it.copy(weekly = v) } }

    fun setUpstream(v: String) {
        prefs.upstreamDns = v
        _state.update { it.copy(upstream = v) }
        AdBlockVpnService.reloadIfRunning(ctx)
    }

    fun setAdguardList(v: Boolean) {
        prefs.useAdguardList = v
        _state.update { it.copy(adguardList = v) }
        if (v) updateListsNow() else AdBlockVpnService.reloadIfRunning(ctx)
    }

    fun toggleExcluded(pkg: String) {
        val cur = prefs.vpnExcludedApps
        prefs.vpnExcludedApps = if (pkg in cur) cur - pkg else cur + pkg
        _state.update { it.copy(excluded = prefs.vpnExcludedApps) }
        AdBlockVpnService.reloadIfRunning(ctx)
    }

    fun allowDomain(domain: String) {
        val d = HostsParser.parseLine(domain.trim())
        if (d == null) {
            _state.update { it.copy(message = "Érvénytelen cím: $domain") }
            return
        }
        prefs.allowedDomains = prefs.allowedDomains + d
        _state.update { it.copy(allowed = prefs.allowedDomains, message = "Engedélyezve: $d") }
        AdBlockVpnService.reloadIfRunning(ctx)
    }

    fun removeAllowed(domain: String) {
        prefs.allowedDomains = prefs.allowedDomains - domain
        _state.update { it.copy(allowed = prefs.allowedDomains) }
        AdBlockVpnService.reloadIfRunning(ctx)
    }

    fun updateListsNow() {
        if (_state.value.updatingLists) return
        viewModelScope.launch {
            _state.update { it.copy(updatingLists = true) }
            val ok = withContext(Dispatchers.IO) { DomainBlocklist.update(ctx) }
            if (ok) AdBlockVpnService.reloadIfRunning(ctx)
            _state.update {
                it.copy(
                    updatingLists = false,
                    lastHostsUpdate = prefs.lastHostsUpdate,
                    message = if (ok) "Reklámlista frissítve." else "Nem sikerült letölteni a listát (nincs internet?). A régi lista marad.",
                )
            }
        }
    }

    fun consumeMessage() = _state.update { it.copy(message = null) }
}
