package hu.csakoattila.adwarescanner.vpn;

import java.util.Locale;
import java.util.Set;

/**
 * Reklámlisták sorainak feldolgozása és a domain-egyezés vizsgálata.
 * Támogatott formátumok:
 *   - hosts:          "0.0.0.0 ads.example.com" / "127.0.0.1 ads.example.com"
 *   - sima domain:    "ads.example.com"
 *   - AdGuard/ABP:    "||ads.example.com^"  (kivételek "@@||...^" külön kezelve)
 */
public final class HostsParser {

    private HostsParser() {}

    /** A sorból kiolvasott blokkolandó domain, vagy null. */
    public static String parseLine(String raw) {
        if (raw == null) return null;
        String line = raw.trim();
        if (line.isEmpty()) return null;
        char c0 = line.charAt(0);
        if (c0 == '#' || c0 == '!' || c0 == '[') return null;
        int hash = line.indexOf('#');
        if (hash > 0) line = line.substring(0, hash).trim();

        String d;
        if (line.startsWith("@@")) {
            return null; // kivétel – lásd parseAllowLine
        } else if (line.startsWith("||")) {
            int end = line.indexOf('^');
            if (end < 0) end = line.length();
            // módosítós szabályokat (pl. $important) csak akkor fogadunk, ha a végén nincs más
            String rest = line.substring(end).replace("^", "");
            if (!rest.isEmpty() && !rest.equals("$important")) return null;
            d = line.substring(2, end);
        } else {
            String[] parts = line.split("\\s+");
            if (parts.length >= 2 && (parts[0].equals("0.0.0.0") || parts[0].equals("127.0.0.1")
                    || parts[0].equals("::") || parts[0].equals("::1"))) {
                d = parts[1];
            } else if (parts.length == 1) {
                d = parts[0];
            } else {
                return null;
            }
        }
        return normalize(d);
    }

    /** AdGuard-kivétel ("@@||example.com^") domainje, vagy null. */
    public static String parseAllowLine(String raw) {
        if (raw == null) return null;
        String line = raw.trim();
        if (!line.startsWith("@@||")) return null;
        int end = line.indexOf('^');
        if (end < 0) end = line.length();
        return normalize(line.substring(4, end));
    }

    static String normalize(String d) {
        if (d == null) return null;
        d = d.trim().toLowerCase(Locale.ROOT);
        if (d.endsWith(".")) d = d.substring(0, d.length() - 1);
        if (d.isEmpty() || d.length() > 253 || d.indexOf('.') < 0) return null;
        if (d.equals("localhost") || d.endsWith(".local") || d.equals("0.0.0.0")
                || d.equals("broadcasthost") || d.equals("localhost.localdomain")) return null;
        for (int i = 0; i < d.length(); i++) {
            char c = d.charAt(i);
            boolean ok = (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '.' || c == '_';
            if (!ok) return null; // csillag, perjel stb. – nem egyszerű domain
        }
        // csupa számjegy és pont = IP-cím, nem domain
        if (d.matches("[0-9.]+")) return null;
        return d;
    }

    /**
     * A domain vagy bármely szülője szerepel-e a halmazban.
     * Pl. "x.ads.example.com" egyezik, ha "ads.example.com" a listán van.
     */
    public static boolean matches(Set<String> set, String domain) {
        if (domain == null || set.isEmpty()) return false;
        String d = domain;
        while (true) {
            if (set.contains(d)) return true;
            int dot = d.indexOf('.');
            if (dot < 0) return false;
            d = d.substring(dot + 1);
            if (d.indexOf('.') < 0) return false; // TLD-t ("com") nem vizsgálunk
        }
    }
}
