package hu.csakoattila.adwarescanner.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/** A reklámszűrő és -figyelő beállításai. */
@Composable
fun AdSettingsScreen(s: AdsState, vm: AdsViewModel, onBack: () -> Unit, modifier: Modifier = Modifier) {
    BackHandler(onBack = onBack)
    var showAllApps by rememberSaveable { mutableStateOf(false) }
    var newDomain by remember { mutableStateOf("") }
    val labelOf = remember(s.userApps) { s.userApps.associate { it.packageName to it.label } }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Vissza") }
                Text("Reklámszűrő beállításai", style = MaterialTheme.typography.titleLarge)
            }
        }

        // --- Reklámfigyelő ---
        item { Section("Reklámfigyelő") }
        item {
            Column {
                Text("Figyelmeztetés, ha egy app napi ${s.threshold} teljes képernyős reklámot elér", fontSize = 14.sp)
                Slider(
                    value = s.threshold.toFloat(),
                    onValueChange = { vm.setThreshold((it / 5f).roundToInt() * 5) },
                    valueRange = 5f..50f,
                    steps = 8,
                )
            }
        }
        item {
            SwitchRow(
                "Automatikus blokkolás",
                "Ha egy app akkor mutat reklámot, amikor nem azt használod, elvágjuk az internetét (ha a reklámszűrő fut).",
                s.autoBlock, vm::setAutoBlock,
            )
        }
        item { SwitchRow("Heti összesítő", "Hetente egy értesítés a blokkolt reklámokról.", s.weekly, vm::setWeekly) }

        // --- DNS és listák ---
        item { Section("DNS-szerver") }
        item { RadioRow("A hálózat saját DNS-e (alapértelmezett)", s.upstream == "system") { vm.setUpstream("system") } }
        item { RadioRow("AdGuard DNS (ingyenes, maga is szűri a reklámokat)", s.upstream == "adguard") { vm.setUpstream("adguard") } }

        item { Section("Reklámlisták") }
        item {
            SwitchRow(
                "AdGuard DNS-szűrő lista is",
                "A StevenBlack-lista mellé egy második, bővebb lista. Hetente letöltődik.",
                s.adguardList, vm::setAdguardList,
            )
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Utolsó frissítés: ${formatTime(s.lastHostsUpdate)}", fontSize = 13.sp, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { vm.updateListsNow() }, enabled = !s.updatingLists) {
                    Text(if (s.updatingLists) "Letöltés…" else "Frissítés most")
                }
            }
        }

        // --- Kizárt appok ---
        item { Section("Szűrésből kizárt appok") }
        item {
            Text(
                "Ezek az appok teljesen kimaradnak a szűrésből (pl. banki appok). Ha egy app a reklámszűrő mellett nem működik jól, tedd ide.",
                fontSize = 13.sp, color = Color.Gray,
            )
        }
        val excludedApps = s.userApps.filter { it.packageName in s.excluded }
        val shownApps = if (showAllApps) s.userApps else excludedApps
        items(shownApps, key = { "ex_" + it.packageName }) { app ->
            Row(
                Modifier.fillMaxWidth().clickable { vm.toggleExcluded(app.packageName) },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Checkbox(checked = app.packageName in s.excluded, onCheckedChange = { vm.toggleExcluded(app.packageName) })
                AppIcon(app.packageName, 28.dp)
                Spacer(Modifier.width(8.dp))
                Text(app.label, fontSize = 14.sp)
            }
        }
        item {
            TextButton(onClick = { showAllApps = !showAllApps }) {
                Text(if (showAllApps) "Csak a kizártak mutatása" else "App hozzáadása a kizártakhoz…")
            }
        }

        // --- Engedélyezett címek ---
        item { Section("Engedélyezett címek") }
        item {
            Text(
                "Ha egy oldal vagy funkció nem működik, engedélyezd a címét – az aldomainjeivel együtt sosem lesz blokkolva.",
                fontSize = 13.sp, color = Color.Gray,
            )
        }
        items(s.allowed.sorted(), key = { "al_$it" }) { d ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(d, fontSize = 14.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.removeAllowed(d) }) { Icon(Icons.Filled.Close, "Törlés") }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newDomain, onValueChange = { newDomain = it },
                    placeholder = { Text("pl. pelda.hu") }, singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { vm.allowDomain(newDomain); newDomain = "" }, enabled = newDomain.isNotBlank()) {
                    Text("Hozzáad")
                }
            }
        }

        // --- Napló ---
        item { Section("Legutóbb blokkolt címek") }
        if (s.recentDomains.isEmpty()) {
            item { Text("Még nincs blokkolt cím.", fontSize = 13.sp, color = Color.Gray) }
        }
        items(s.recentDomains.take(100)) { b ->
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(b.domain, fontSize = 14.sp)
                        Text(
                            formatTime(b.ts) + (if (b.packageName.isNotEmpty()) " · " + (labelOf[b.packageName] ?: b.packageName) else ""),
                            fontSize = 11.sp, color = Color.Gray,
                        )
                    }
                    if (b.domain !in s.allowed) {
                        TextButton(onClick = { vm.allowDomain(b.domain) }) { Text("Engedélyez") }
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(title, fontWeight = FontWeight.Bold, color = Brand, modifier = Modifier.padding(top = 12.dp))
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp)
            Text(sub, fontSize = 12.sp, color = Color.Gray)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun RadioRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(text, fontSize = 14.sp)
    }
}
