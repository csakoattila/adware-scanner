package hu.csakoattila.adwarescanner.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import hu.csakoattila.adwarescanner.ads.AdTools

/** A „Reklámok” fül. */
@Composable
fun AdsScreen(
    s: AdsState,
    vm: AdsViewModel,
    onToggleVpn: (Boolean) -> Unit,
    onOpenSettings: () -> Unit,
    openIntent: (Intent) -> Unit,
    onUninstall: (String) -> Unit,
    onReport: (pkg: String, note: String) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { VpnCard(s, onToggleVpn, onOpenSettings) }

        if (!s.usageAccess) {
            item {
                HintCard(
                    title = "Reklámfigyelő bekapcsolása",
                    text = "Ahhoz, hogy az app észrevegye a teljes képernyős reklámokat, engedélyezd a „Használati adatokhoz való hozzáférést” az Adware Scanner számára. Az adatok a telefonon maradnak.",
                    button = "Engedély megadása",
                    onClick = { openIntent(AdTools.usageAccessIntent()) },
                )
            }
        }
        if (s.vpnOn && s.privateDnsStrict) {
            item {
                HintCard(
                    title = "A Privát DNS megkerüli a szűrőt",
                    text = "A telefonon egyéni Privát DNS szerver van beállítva, így a reklámszűrő nem látja a kéréseket. Állítsd a Privát DNS-t „Automatikus” vagy „Ki” értékre (Beállítások → Hálózat → Privát DNS).",
                    button = "Hálózati beállítások",
                    onClick = { openIntent(AdTools.networkSettingsIntent()) },
                )
            }
        }
        if (s.vpnOn && !s.perAppSupported) {
            item {
                Text(
                    "Ezen az Android-verzión a szűrés működik, de a blokkolt címeket nem tudjuk appokra bontani (ehhez Android 10 kell).",
                    fontSize = 12.sp, color = Color.Gray,
                )
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Reklámos appok", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                FilterChip(selected = s.period == 1, onClick = { vm.setPeriod(1) }, label = { Text("Ma") })
                FilterChip(selected = s.period == 7, onClick = { vm.setPeriod(7) }, label = { Text("7 nap") })
                FilterChip(selected = s.period == 30, onClick = { vm.setPeriod(30) }, label = { Text("30 nap") })
            }
        }

        if (!s.loading && s.rows.isEmpty()) {
            item {
                Text(
                    if (s.usageAccess || s.vpnOn) {
                        "Ebben az időszakban nem észleltünk reklámot. A figyelő negyedóránként nézi meg az új eseményeket."
                    } else {
                        "Még nincs adat. Kapcsold be a reklámfigyelőt (fenti engedély) vagy a reklámszűrőt."
                    },
                    color = Color.Gray, fontSize = 14.sp,
                )
            }
        }

        items(s.rows, key = { it.packageName }) { row ->
            AdRowCard(row, onClick = { vm.openDetails(row) })
        }
    }

    s.details?.let { d ->
        AdDetailsDialog(
            d = d,
            vpnOn = s.vpnOn,
            onDismiss = { vm.closeDetails() },
            onBlock = { vm.block(d.row.packageName) },
            onUnblock = { vm.unblock(d.row.packageName) },
            onMute = { vm.mute(d.row.packageName) },
            onUnmute = { vm.unmute(d.row.packageName) },
            openIntent = openIntent,
            onUninstall = { vm.closeDetails(); onUninstall(d.row.packageName) },
            onReport = { onReport(d.row.packageName, vm.reportNote(d.row)) },
        )
    }
}

@Composable
private fun VpnCard(s: AdsState, onToggle: (Boolean) -> Unit, onSettings: () -> Unit) {
    val bg = if (s.vpnOn) Brand else Color(0xFF4E5D54)
    Card(colors = CardDefaults.cardColors(containerColor = bg), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Reklámszűrő", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (s.vpnOn) "Bekapcsolva – a reklámok nem töltődnek be" else "Kikapcsolva",
                        color = Color.White.copy(alpha = .9f), fontSize = 13.sp,
                    )
                }
                IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Beállítások", tint = Color.White) }
                Switch(checked = s.vpnOn, onCheckedChange = onToggle)
            }
            Spacer(Modifier.heightIn(min = 10.dp))
            Text(
                "Ma: ${s.blockedToday} blokkolt reklámcím · ${s.fsInToday + s.fsOutToday} teljes képernyős reklám" +
                    if (s.fsOutToday > 0) " (${s.fsOutToday} appon kívül)" else "",
                color = Color.White, fontSize = 14.sp,
            )
            if (!s.vpnOn) {
                Text(
                    "Bekapcsoláskor a telefon egy „Kapcsolódási kérés” ablakot mutat – ez a telefonon belüli szűrő, adat nem megy külső szerverre.",
                    color = Color.White.copy(alpha = .85f), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
    }
}

@Composable
private fun HintCard(title: String, text: String, button: String, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4E0))) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(text, fontSize = 14.sp)
            TextButton(onClick = onClick) { Text(button) }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AdRowCard(row: AdAppRow, onClick: () -> Unit) {
    val st = row.stat
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = when {
                row.blocked -> Color(0xFFFDECEA)
                st.fullscreenOutOfApp > 0 -> Color(0xFFFFF4E0)
                else -> Color.White
            },
        ),
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            AppIcon(row.packageName, 40.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(row.label, fontWeight = FontWeight.SemiBold)
                val parts = buildList {
                    if (st.fullscreenTotal > 0) add("${st.fullscreenTotal} teljes képernyős")
                    if (st.fullscreenOutOfApp > 0) add("${st.fullscreenOutOfApp} appon kívül")
                    if (st.dnsBlocked > 0) add("${st.dnsBlocked} blokkolt cím")
                }
                if (parts.isNotEmpty()) Text(parts.joinToString(" · "), fontSize = 13.sp)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                    if (row.blocked) Badge(if (row.autoBlocked) "Blokkolva (automatikusan)" else "Blokkolva", Danger)
                    if (row.overlay) Badge("Más appok felett is megjelenhet", Warn)
                    if (row.muted) Badge("Elnémítva", Color.Gray)
                    if (row.isSystem) Badge("Rendszerapp", Color.Gray)
                }
            }
        }
    }
}

@Composable
private fun Badge(text: String, color: Color) {
    Text(
        text, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.background(color, RoundedCornerShape(50)).padding(horizontal = 8.dp, vertical = 2.dp),
    )
}

@Composable
private fun AdDetailsDialog(
    d: AdDetails,
    vpnOn: Boolean,
    onDismiss: () -> Unit,
    onBlock: () -> Unit,
    onUnblock: () -> Unit,
    onMute: () -> Unit,
    onUnmute: () -> Unit,
    openIntent: (Intent) -> Unit,
    onUninstall: () -> Unit,
    onReport: () -> Unit,
) {
    val r = d.row
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(r.packageName, 32.dp)
                Spacer(Modifier.width(10.dp))
                Text(r.label)
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(r.packageName, fontSize = 11.sp, color = Color.Gray)
                Text(
                    "Teljes képernyős reklám: ${r.stat.fullscreenTotal} (appon kívül: ${r.stat.fullscreenOutOfApp}) · blokkolt reklámcím: ${r.stat.dnsBlocked}",
                    fontSize = 13.sp,
                )
                if (r.stat.fullscreenOutOfApp > 0) {
                    Text(
                        "Appon kívüli reklám: akkor jelent meg, amikor nem ezt az appot használtad. Ez kéretlen reklámprogramra utal.",
                        fontSize = 13.sp, color = Danger,
                    )
                }
                if (r.overlay) {
                    Text(
                        "Engedélye van más appok felett megjelenni – így lebegő reklámokat is mutathat. Ha nem tudod, miért kell neki, vond vissza.",
                        fontSize = 13.sp, color = Warn,
                    )
                }

                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                // műveletek
                if (r.blocked) {
                    OutlinedButton(onClick = onUnblock, modifier = Modifier.fillMaxWidth()) { Text("Internet visszaállítása") }
                } else if (!r.isSystem) {
                    OutlinedButton(onClick = onBlock, enabled = vpnOn, modifier = Modifier.fillMaxWidth()) { Text("Internet elvágása") }
                    if (!vpnOn) Text("Az internet elvágásához kapcsold be a reklámszűrőt.", fontSize = 12.sp, color = Color.Gray)
                }
                if (r.overlay) {
                    OutlinedButton(onClick = { openIntent(AdTools.overlaySettingsIntent(r.packageName)) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Más appok feletti megjelenítés")
                    }
                }
                OutlinedButton(onClick = { openIntent(AdTools.notificationSettingsIntent(r.packageName)) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Értesítések beállítása")
                }
                if (!r.isSystem) {
                    OutlinedButton(onClick = onReport, modifier = Modifier.fillMaxWidth()) { Text("Bejelentem") }
                    OutlinedButton(onClick = onUninstall, modifier = Modifier.fillMaxWidth()) { Text("Törlés") }
                }
                TextButton(onClick = if (r.muted) onUnmute else onMute) {
                    Text(if (r.muted) "Figyelmeztetések visszakapcsolása" else "Nem kérek róla figyelmeztetést")
                }

                if (d.events.isNotEmpty()) {
                    HorizontalDivider(Modifier.padding(vertical = 4.dp))
                    Text("Legutóbbi teljes képernyős reklámok", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    d.events.take(15).forEach { e ->
                        Text(
                            "${formatTime(e.ts)} · " + if (e.outOfApp) "appon kívül" else "appon belül",
                            fontSize = 12.sp, color = if (e.outOfApp) Danger else Color.Unspecified,
                        )
                    }
                }
                if (d.domains.isNotEmpty()) {
                    HorizontalDivider(Modifier.padding(vertical = 4.dp))
                    Text("Legutóbb blokkolt címek", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    d.domains.take(15).forEach { b -> Text("${formatTime(b.ts)} · ${b.domain}", fontSize = 12.sp) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Bezárás") } },
    )
}
