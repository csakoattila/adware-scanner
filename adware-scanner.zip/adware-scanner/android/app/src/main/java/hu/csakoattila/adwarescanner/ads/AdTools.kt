package hu.csakoattila.adwarescanner.ads

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.provider.Settings
import hu.csakoattila.adwarescanner.data.InstalledApp

/** Segédfüggvények a reklám-funkciókhoz: engedélyek, beállítás-képernyők, javasolt kizárások. */
object AdTools {

    /** Megkapta-e az app a „Megjelenítés más alkalmazások felett” engedélyt (lebegő reklámokhoz kell). */
    fun canDrawOverlays(context: Context, pkg: String): Boolean {
        val pm = context.packageManager
        val uid = try {
            pm.getApplicationInfo(pkg, 0).uid
        } catch (e: PackageManager.NameNotFoundException) {
            return false
        }
        // csak az számít, aki egyáltalán kéri az engedélyt
        if (pm.checkPermission(Manifest.permission.SYSTEM_ALERT_WINDOW, pkg) != PackageManager.PERMISSION_GRANTED &&
            !requests(context, pkg, Manifest.permission.SYSTEM_ALERT_WINDOW)
        ) return false
        val ops = context.getSystemService(AppOpsManager::class.java) ?: return false
        val mode = try {
            if (Build.VERSION.SDK_INT >= 29) {
                ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW, uid, pkg)
            } else {
                @Suppress("DEPRECATION")
                ops.checkOpNoThrow(AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW, uid, pkg)
            }
        } catch (e: SecurityException) {
            return false
        }
        return when (mode) {
            AppOpsManager.MODE_ALLOWED -> true
            AppOpsManager.MODE_DEFAULT ->
                pm.checkPermission(Manifest.permission.SYSTEM_ALERT_WINDOW, pkg) == PackageManager.PERMISSION_GRANTED
            else -> false
        }
    }

    private fun requests(context: Context, pkg: String, permission: String): Boolean = try {
        @Suppress("DEPRECATION")
        val info = context.packageManager.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
        info.requestedPermissions?.contains(permission) == true
    } catch (e: Exception) {
        false
    }

    fun overlaySettingsIntent(pkg: String): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg"))

    fun notificationSettingsIntent(pkg: String): Intent =
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg)

    fun appDetailsIntent(pkg: String): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))

    fun usageAccessIntent(): Intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)

    /** A Privát DNS beállítás a hálózati beállítások között van; ez a legközelebbi általános képernyő. */
    fun networkSettingsIntent(): Intent = Intent(Settings.ACTION_WIRELESS_SETTINGS)

    /**
     * Be van-e kapcsolva a Privát DNS konkrét szerverrel (szigorú mód).
     * Ilyenkor a rendszer titkosítva, közvetlenül a megadott szerverhez fordul, és megkerüli a szűrőt.
     */
    fun isPrivateDnsStrict(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < 28) return false
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return false
        @Suppress("DEPRECATION")
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
            val lp = cm.getLinkProperties(n) ?: continue
            if (lp.privateDnsServerName != null) return true
        }
        return false
    }

    /**
     * Javasolt kizárások a VPN-szűrésből: banki és fizetési appok, hogy biztosan ne romoljon el semmi.
     * (Név- és csomagnév-alapú felismerés; a felhasználó a beállításokban módosíthatja.)
     */
    fun suggestedExclusions(apps: List<InstalledApp>): Set<String> {
        val known = setOf(
            "com.revolut.revolut",
            "com.paypal.android.p2pmobile",
            "com.transferwise.android",
            "com.google.android.apps.walletnfcrel",
        )
        val words = listOf("bank", "banka", "mobilbank", "netbank", "wallet", "simplepay")
        return apps.asSequence()
            .filter { a ->
                a.packageName in known ||
                    words.any { w -> a.packageName.lowercase().contains(w) || a.label.lowercase().contains(w) }
            }
            .map { it.packageName }
            .toSet()
    }
}
