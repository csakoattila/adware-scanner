package hu.csakoattila.adwarescanner.vpn

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.Process
import android.system.OsConstants
import android.util.Log
import hu.csakoattila.adwarescanner.ads.AdDb
import hu.csakoattila.adwarescanner.ads.BlockedDomain
import hu.csakoattila.adwarescanner.data.Prefs
import hu.csakoattila.adwarescanner.ui.MainActivity
import hu.csakoattila.adwarescanner.work.Notifier
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Helyi, csak DNS-t szűrő VPN.
 * A rendszer DNS-szervereként a 10.111.222.2 virtuális címet adja meg, és csak ezt a címet irányítja
 * a VPN-be – minden más forgalom (böngészés, videó) közvetlenül megy, nem érinti.
 * A tiltott címekre NXDOMAIN választ ad, a többit továbbítja a valódi DNS-szervernek.
 */
class AdBlockVpnService : VpnService() {

    private lateinit var prefs: Prefs
    private lateinit var db: AdDb

    @Volatile private var tun: ParcelFileDescriptor? = null
    @Volatile private var reader: Thread? = null
    @Volatile private var blocklist: DomainBlocklist? = null
    @Volatile private var blockedApps: Set<String> = emptySet()
    @Volatile private var excludedApps: Set<String> = emptySet()

    private var forwardPool: ExecutorService? = null
    private var scheduler: ScheduledExecutorService? = null
    private val writeLock = Any()

    private val pendingCounts = ConcurrentHashMap<String, AtomicInteger>()
    private val pendingRecent = ConcurrentLinkedQueue<BlockedDomain>()
    private val uidToPkg = ConcurrentHashMap<Int, String>()
    private var lastNotifiedCount = -1
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var currentDay = AdDb.day(System.currentTimeMillis())

    @Volatile private var cachedUpstream: InetAddress? = null
    @Volatile private var upstreamCheckedAt = 0L

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        db = AdDb.get(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                prefs.vpnEnabled = false
                shutdown()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RELOAD -> {
                if (tun == null) startVpn() else reload()
            }
            else -> startVpn() // ACTION_START, mindig bekapcsolt VPN (null / SERVICE_INTERFACE)
        }
        return START_STICKY
    }

    override fun onRevoke() {
        // másik VPN indult, vagy a felhasználó a beállításokban bontotta a kapcsolatot
        prefs.vpnEnabled = false
        shutdown()
        Notifier.notifyVpnStopped(this)
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------------

    private fun startVpn() {
        if (tun != null) return
        if (VpnService.prepare(this) != null) {
            // nincs (már) VPN-engedély – a felhasználónak újra be kell kapcsolnia az appban
            prefs.vpnEnabled = false
            stopSelf()
            return
        }
        prefs.vpnEnabled = true
        blockedApps = prefs.blockedApps
        forwardPool = Executors.newFixedThreadPool(8)
        scheduler = Executors.newSingleThreadScheduledExecutor().also { s ->
            s.scheduleWithFixedDelay({ flush() }, 30, 30, TimeUnit.SECONDS)
            // lista betöltése háttérben; addig minden kérést továbbítunk
            s.execute {
                blocklist = DomainBlocklist.load(this)
                running.set(true)
            }
        }
        liveBlockedToday.set(runCatching { db.totalDnsBlocked(1) }.getOrDefault(0))
        if (!establish()) {
            shutdown()
            stopSelf()
            return
        }
        Notifier.updateVpnNotification(this, liveBlockedToday.get(), blockedApps.size)
    }

    private fun establish(): Boolean {
        excludedApps = prefs.vpnExcludedApps
        val b = Builder()
            .setSession("Adware Scanner reklámszűrő")
            .addAddress(VPN_ADDRESS, 32)
            .addDnsServer(VPN_DNS)
            .addRoute(VPN_DNS, 32)
            .setBlocking(true)
            .setConfigureIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                ),
            )
        if (Build.VERSION.SDK_INT >= 29) b.setMetered(false)
        // a saját forgalmunk (lista letöltése, továbbított DNS) ne menjen a VPN-be
        runCatching { b.addDisallowedApplication(packageName) }
        for (p in excludedApps) runCatching { b.addDisallowedApplication(p) }

        val fd = try {
            b.establish()
        } catch (e: Exception) {
            Log.e(TAG, "establish() sikertelen", e)
            null
        } ?: return false
        tun = fd
        reader = Thread({ readLoop(fd) }, "vpn-reader").also { it.start() }
        instance = this
        isActive = true
        return true
    }

    private fun reload() {
        blockedApps = prefs.blockedApps
        scheduler?.execute { blocklist = DomainBlocklist.load(this) }
        if (prefs.vpnExcludedApps != excludedApps) {
            // a kizárások csak új kapcsolattal módosíthatók
            val old = tun
            tun = null
            runCatching { old?.close() }
            establish()
        }
        Notifier.updateVpnNotification(this, liveBlockedToday.get(), blockedApps.size)
    }

    private fun shutdown() {
        isActive = false
        if (instance === this) instance = null
        running.set(false)
        val t = tun
        tun = null
        runCatching { t?.close() }
        reader?.interrupt()
        reader = null
        flush()
        scheduler?.shutdownNow(); scheduler = null
        forwardPool?.shutdownNow(); forwardPool = null
        Notifier.cancelVpnNotification(this)
    }

    // ------------------------------------------------------------------

    private fun readLoop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32_767)
        try {
            while (!Thread.currentThread().isInterrupted && tun === fd) {
                val n = input.read(buf)
                if (n <= 0) continue
                val q = DnsPacket.parse(buf, n) ?: continue
                handleQuery(q, output)
            }
        } catch (e: IOException) {
            // a fd lezárása (leállítás / újraépítés) ide fut – ez a normál kilépés
        } catch (e: Exception) {
            Log.e(TAG, "VPN olvasási hiba", e)
        }
    }

    private fun handleQuery(q: DnsPacket.Query, output: FileOutputStream) {
        val pkg = ownerPackage(q)
        val name = q.name

        val appBlocked = pkg.isNotEmpty() && pkg in blockedApps
        val adBlocked = !appBlocked && blocklist?.isBlocked(name) == true

        if (appBlocked || adBlocked) {
            if (adBlocked && name != null && q.qtype == 1) {
                // statisztika csak az A-kérésekből, hogy egy reklámcím ne számítson többször (A + AAAA + HTTPS)
                pendingCounts.getOrPut(pkg) { AtomicInteger() }.incrementAndGet()
                pendingRecent.add(BlockedDomain(System.currentTimeMillis(), pkg, name))
                liveBlockedToday.incrementAndGet()
            }
            write(output, DnsPacket.buildResponse(q, DnsPacket.nxdomain(q.dns)))
            return
        }
        forwardPool?.execute { forward(q, output) }
    }

    private fun forward(q: DnsPacket.Query, output: FileOutputStream) {
        val primary = upstream()
        var answer = query(primary, q.dns)
        if (answer == null && primary.hostAddress != ADGUARD_DNS) {
            answer = query(InetAddress.getByName(ADGUARD_DNS), q.dns) // tartalék, ha a hálózat DNS-e nem válaszol
        }
        if (answer != null) write(output, DnsPacket.buildResponse(q, answer))
    }

    private fun query(server: InetAddress, dns: ByteArray): ByteArray? = try {
        DatagramSocket().use { s ->
            protect(s)
            s.soTimeout = 5_000
            s.send(DatagramPacket(dns, dns.size, server, 53))
            val buf = ByteArray(4096)
            val resp = DatagramPacket(buf, buf.size)
            s.receive(resp)
            buf.copyOf(resp.length)
        }
    } catch (e: Exception) {
        null
    }

    private fun write(output: FileOutputStream, packet: ByteArray) {
        synchronized(writeLock) {
            try {
                output.write(packet)
            } catch (e: IOException) {
                // a kapcsolat közben lezárult
            }
        }
    }

    /** A továbbító DNS-szerver: AdGuard, vagy a valódi hálózat (wifi/mobilnet) saját DNS-e. */
    private fun upstream(): InetAddress {
        if (prefs.upstreamDns == "adguard") return InetAddress.getByName(ADGUARD_DNS)
        val now = System.currentTimeMillis()
        cachedUpstream?.let { if (now - upstreamCheckedAt < 15_000) return it }
        val cm = getSystemService(ConnectivityManager::class.java)
        // a saját appunk ki van zárva a VPN-ből, így az activeNetwork a valódi hálózat
        val servers = cm?.activeNetwork?.let { cm.getLinkProperties(it)?.dnsServers }.orEmpty()
            .filter { it.hostAddress != VPN_DNS }
        val chosen = servers.firstOrNull { it is Inet4Address } ?: servers.firstOrNull()
            ?: InetAddress.getByName(ADGUARD_DNS)
        cachedUpstream = chosen
        upstreamCheckedAt = now
        return chosen
    }

    /** Melyik app küldte a kérést (Android 10+). Üres szöveg, ha nem állapítható meg. */
    private fun ownerPackage(q: DnsPacket.Query): String {
        if (Build.VERSION.SDK_INT < 29) return ""
        return try {
            val cm = getSystemService(ConnectivityManager::class.java) ?: return ""
            val uid = cm.getConnectionOwnerUid(
                OsConstants.IPPROTO_UDP,
                InetSocketAddress(InetAddress.getByAddress(q.srcIp), q.srcPort),
                InetSocketAddress(InetAddress.getByAddress(q.dstIp), q.dstPort),
            )
            if (uid == Process.INVALID_UID || uid < 0) return ""
            uidToPkg[uid] ?: (packageManager.getPackagesForUid(uid)?.firstOrNull() ?: "").also { uidToPkg[uid] = it }
        } catch (e: Exception) {
            ""
        }
    }

    /** A számlálók kiírása az adatbázisba és az értesítés frissítése (félpercenként). */
    private fun flush() {
        val counts = HashMap<String, Int>()
        for (k in pendingCounts.keys.toList()) {
            val v = pendingCounts.remove(k)?.get() ?: 0
            if (v > 0) counts[k] = v
        }
        val recent = ArrayList<BlockedDomain>()
        while (true) recent += pendingRecent.poll() ?: break
        runCatching { db.addDnsBlocked(counts, recent) }
        val today = AdDb.day(System.currentTimeMillis())
        if (today != currentDay) {
            // éjfél után a mai számláló nulláról indul
            currentDay = today
            liveBlockedToday.set(runCatching { db.totalDnsBlocked(1) }.getOrDefault(0))
        }
        val total = liveBlockedToday.get()
        if (isActive && total != lastNotifiedCount) {
            lastNotifiedCount = total
            Notifier.updateVpnNotification(this, total, blockedApps.size)
        }
    }

    companion object {
        private const val TAG = "AdBlockVpn"
        const val ACTION_START = "hu.csakoattila.adwarescanner.vpn.START"
        const val ACTION_STOP = "hu.csakoattila.adwarescanner.vpn.STOP"
        const val ACTION_RELOAD = "hu.csakoattila.adwarescanner.vpn.RELOAD"
        const val VPN_ADDRESS = "10.111.222.1"
        const val VPN_DNS = "10.111.222.2"
        const val ADGUARD_DNS = "94.140.14.14"

        /** Fut-e most a szűrő (a felület ebből olvas). */
        @Volatile var isActive = false
            private set

        /** A lista betöltődött és a szűrés ténylegesen működik. */
        val running = java.util.concurrent.atomic.AtomicBoolean(false)

        /** A mai blokkolt reklámcímek száma (élő érték). */
        val liveBlockedToday = AtomicInteger(0)

        fun start(context: Context) {
            context.startService(Intent(context, AdBlockVpnService::class.java).setAction(ACTION_START))
        }

        fun stop(context: Context) {
            context.startService(Intent(context, AdBlockVpnService::class.java).setAction(ACTION_STOP))
        }

        @Volatile private var instance: AdBlockVpnService? = null

        /**
         * Beállítások / blokkolt appok / lista változott: ha fut, újratölti.
         * Közvetlen hívás (ugyanaz a folyamat), mert háttérből – pl. a WorkManager-ből – startService() nem engedélyezett.
         */
        fun reloadIfRunning(@Suppress("UNUSED_PARAMETER") context: Context) {
            val svc = instance ?: return
            svc.mainHandler.post { if (isActive) svc.reload() }
        }
    }
}
