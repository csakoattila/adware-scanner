package hu.csakoattila.adwarescanner.ads

/**
 * Ismert reklám-SDK-k teljes képernyős reklám-képernyőinek osztálynév-előtagjai.
 * Ha egy app ilyen képernyőt nyit meg, az egy teljes képernyős (interstitial/videó) reklám.
 *
 * A lista a szerver tiltólistájának "ad_activity_prefixes" mezőjéből bővülhet (ha a szerver elérhető).
 */
object AdSignatures {
    val BUILT_IN: List<String> = listOf(
        // Google AdMob / Ad Manager
        "com.google.android.gms.ads.AdActivity",
        "com.google.android.gms.ads.OutOfContextTestingActivity",
        // AppLovin / MAX
        "com.applovin.adview.",
        "com.applovin.sdk.AppLovinWebViewActivity",
        "com.applovin.impl.adview.",
        // Unity Ads
        "com.unity3d.services.ads.adunit.",
        "com.unity3d.ads.adunit.",
        "com.unity3d.ads.",
        // ironSource / LevelPlay
        "com.ironsource.sdk.controller.",
        "com.ironsource.mediationsdk.",
        "com.ironsource.adapters.",
        "com.ironsource.lifecycle.",
        // Vungle / Liftoff
        "com.vungle.ads.",
        "com.vungle.warren.",
        "com.vungle.publisher.",
        // Meta Audience Network
        "com.facebook.ads.AudienceNetworkActivity",
        "com.facebook.ads.internal.",
        // Mintegral
        "com.mbridge.msdk.",
        "com.mintegral.msdk.",
        // Pangle (ByteDance)
        "com.bytedance.sdk.openadsdk.",
        // InMobi
        "com.inmobi.ads.rendering.",
        "com.inmobi.rendering.",
        "com.inmobi.ads.",
        // Chartboost
        "com.chartboost.sdk.",
        // AdColony / Digital Turbine
        "com.adcolony.sdk.",
        "com.fyber.inneractive.",
        "com.fyber.",
        // Yandex
        "com.yandex.mobile.ads.",
        // myTarget
        "com.my.target.",
        // StartApp / Start.io
        "com.startapp.sdk.",
        "com.startapp.android.publish.",
        // MoPub (régi appokban)
        "com.mopub.mobileads.",
        "com.mopub.common.",
        // Tapjoy, Smaato, Ogury, BidMachine, Moloco
        "com.tapjoy.",
        "com.smaato.sdk.",
        "io.presage.",
        "com.ogury.",
        "io.bidmachine.",
        "com.moloco.sdk.",
        // Amazon, Verve/PubNative, HyprMX
        "com.amazon.device.ads.",
        "net.pubnative.lite.",
        "com.hyprmx.",
    )

    @Volatile
    private var prefixes: List<String> = BUILT_IN

    /** A szerverről kapott kiegészítő előtagok beolvasztása. */
    fun merge(extra: Collection<String>) {
        prefixes = (BUILT_IN + extra.filter { it.length in 6..200 }).distinct()
    }

    fun isAdActivity(className: String?): Boolean {
        if (className.isNullOrEmpty()) return false
        val list = prefixes
        for (p in list) {
            if (p.endsWith(".")) {
                if (className.startsWith(p)) return true
            } else if (className == p || className.startsWith("$p$")) {
                return true
            }
        }
        return false
    }
}
