package hu.csakoattila.adwarescanner.vpn;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.junit.Test;

public class DnsPacketTest {

    /** IPv4/UDP DNS-kérés építése (opcionális EDNS OPT rekorddal). */
    private static byte[] query(String name, int id, boolean edns) {
        ByteArrayOutputStream d = new ByteArrayOutputStream();
        d.write(id >> 8); d.write(id); d.write(0x01); d.write(0x00);          // RD
        d.write(0); d.write(1); d.write(0); d.write(0); d.write(0); d.write(0); d.write(0); d.write(edns ? 1 : 0);
        for (String l : name.split("\\.")) { d.write(l.length()); d.write(l.getBytes(), 0, l.length()); }
        d.write(0); d.write(0); d.write(1); d.write(0); d.write(1);
        if (edns) { byte[] opt = {0, 0, 41, 0x10, 0, 0, 0, 0, 0, 0, 0}; d.write(opt, 0, opt.length); }
        byte[] dns = d.toByteArray();
        byte[] p = new byte[28 + dns.length];
        p[0] = 0x45; p[2] = (byte) (p.length >> 8); p[3] = (byte) p.length; p[6] = 0x40; p[8] = 64; p[9] = 17;
        byte[] src = {10, 111, (byte) 222, 1}, dst = {10, 111, (byte) 222, 2};
        System.arraycopy(src, 0, p, 12, 4); System.arraycopy(dst, 0, p, 16, 4);
        p[20] = (byte) 0xC3; p[21] = 0x50; p[23] = 53;
        int ul = 8 + dns.length; p[24] = (byte) (ul >> 8); p[25] = (byte) ul;
        System.arraycopy(dns, 0, p, 28, dns.length);
        return p;
    }

    private static int ipSum(byte[] b) {
        int s = 0;
        for (int i = 0; i < 20; i += 2) s += ((b[i] & 0xFF) << 8) | (b[i + 1] & 0xFF);
        while ((s >> 16) != 0) s = (s & 0xFFFF) + (s >> 16);
        return s;
    }

    @Test public void parsesQuery() {
        byte[] p = query("Ads.Example.com", 0x1234, true);
        DnsPacket.Query q = DnsPacket.parse(p, p.length);
        assertNotNull(q);
        assertEquals("ads.example.com", q.name);
        assertEquals(1, q.qtype);
        assertEquals(50000, q.srcPort);
        assertEquals(53, q.dstPort);
    }

    @Test public void nxdomainDropsOptAndSetsFlags() {
        byte[] p = query("ads.example.com", 0x1234, true);
        byte[] nx = DnsPacket.nxdomain(DnsPacket.parse(p, p.length).dns);
        assertEquals(12 + 17 + 4, nx.length);
        assertEquals(0x12, nx[0] & 0xFF);
        assertEquals(0x34, nx[1] & 0xFF);
        assertTrue((nx[2] & 0x80) != 0);   // QR
        assertTrue((nx[2] & 0x01) != 0);   // RD
        assertEquals(3, nx[3] & 0x0F);     // NXDOMAIN
        assertEquals(0, nx[11]);           // ARCOUNT
    }

    @Test public void responseSwapsAddressesWithValidChecksum() {
        byte[] p = query("x.com", 7, false);
        DnsPacket.Query q = DnsPacket.parse(p, p.length);
        byte[] r = DnsPacket.buildResponse(q, DnsPacket.nxdomain(q.dns));
        assertEquals(0xFFFF, ipSum(r));
        assertArrayEquals(q.dstIp, Arrays.copyOfRange(r, 12, 16));
        assertArrayEquals(q.srcIp, Arrays.copyOfRange(r, 16, 20));
        assertEquals(53, ((r[20] & 0xFF) << 8) | (r[21] & 0xFF));
        assertEquals(50000, ((r[22] & 0xFF) << 8) | (r[23] & 0xFF));
    }

    @Test public void ignoresNonDns() {
        byte[] p = query("x.com", 1, false);
        p[23] = 80;
        assertNull(DnsPacket.parse(p, p.length));
        byte[] v6 = query("x.com", 1, false);
        v6[0] = 0x60;
        assertNull(DnsPacket.parse(v6, v6.length));
        assertNull(DnsPacket.parse(new byte[10], 10));
    }

    @Test public void hostsParser() {
        assertEquals("ads.example.com", HostsParser.parseLine("0.0.0.0 ads.example.com # x"));
        assertNull(HostsParser.parseLine("0.0.0.0 0.0.0.0"));
        assertNull(HostsParser.parseLine("127.0.0.1 localhost"));
        assertNull(HostsParser.parseLine("# komment"));
        assertEquals("doubleclick.net", HostsParser.parseLine("||doubleclick.net^"));
        assertNull(HostsParser.parseLine("||ads.*.com^"));
        assertNull(HostsParser.parseLine("||x.com^$client=1"));
        assertEquals("x.com", HostsParser.parseLine("||x.com^$important"));
        assertNull(HostsParser.parseLine("@@||x.com^"));
        assertEquals("x.com", HostsParser.parseAllowLine("@@||x.com^|"));
        assertNull(HostsParser.parseLine("1.2.3.4"));
    }

    @Test public void domainMatching() {
        Set<String> s = new HashSet<>(Arrays.asList("doubleclick.net", "ads.example.com"));
        assertTrue(HostsParser.matches(s, "stats.g.doubleclick.net"));
        assertTrue(HostsParser.matches(s, "doubleclick.net"));
        assertFalse(HostsParser.matches(s, "example.com"));
        assertFalse(HostsParser.matches(s, "notdoubleclick.net"));
    }
}
