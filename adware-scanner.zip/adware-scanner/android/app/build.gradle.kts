plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "hu.csakoattila.adwarescanner"
    compileSdk = 35

    defaultConfig {
        applicationId = "hu.csakoattila.adwarescanner"
        minSdk = 26          // Android 8.0 – a PackageManager.getChangedPackages() miatt
        targetSdk = 35
        versionCode = 2
        versionName = "1.1.0"

        // A szerver API címe (a csakoattila.hu/adware/ modul)
        buildConfigField("String", "API_BASE", "\"https://csakoattila.hu/adware/api/\"")
        buildConfigField("String", "PUBLIC_URL", "\"https://csakoattila.hu/adware/\"")
        // Kapcsolattartó e-mail (Névjegy oldal) – CSERÉLD KI a valódira:
        buildConfigField("String", "CONTACT_EMAIL", "\"EMAIL@csakoattila.hu\"")
        // Állítsd be a saját GitHub-repód címére:
        buildConfigField("String", "GITHUB_URL", "\"https://github.com/FELHASZNALO/adware-scanner\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.core)
    implementation(libs.androidx.work.runtime.ktx)
    debugImplementation(libs.androidx.ui.tooling)
    testImplementation("junit:junit:4.13.2")
}

// A teljes StevenBlack reklámlista letöltése az APK-ba fordításkor (hetente frissül).
// Ha nincs internet, a fordítás ettől nem áll le: az app a beépített alaplistával indul,
// és futás közben maga tölti le a listát.
val fetchBlocklist by tasks.registering {
    val out = file("src/main/assets/hosts_stevenblack.txt")
    doLast {
        val weekMs = 7L * 24 * 3600 * 1000
        if (out.exists() && System.currentTimeMillis() - out.lastModified() < weekMs) return@doLast
        try {
            val conn = java.net.URI("https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts")
                .toURL().openConnection()
            conn.connectTimeout = 15_000
            conn.readTimeout = 60_000
            val bytes = conn.getInputStream().use { it.readBytes() }
            if (bytes.size > 100_000) {
                out.writeBytes(bytes)
                println("Reklámlista frissítve: ${bytes.size / 1024} KB")
            }
        } catch (e: Exception) {
            logger.warn("A reklámlista letöltése nem sikerült (${e.message}); a meglévő/alaplista marad.")
        }
    }
}
tasks.named("preBuild") { dependsOn(fetchBlocklist) }
