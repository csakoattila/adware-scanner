# Adatkezelési tájékoztató – Adware Scanner


## Mit nem gyűjt az alkalmazás?

- Nem kér fiókot, nevet, telefonszámot vagy e-mail-címet.
- Nem tartalmaz reklámot, analitikát vagy harmadik féltől származó követőkódot.
- A telefonon lévő alkalmazások listáját **nem küldi el**. Az ellenőrzés a telefonon történik.

## Mikor kommunikál a szerverrel?

1. **Tiltólista letöltése** (naponta egyszer, illetve kérésre). Ez egy egyszerű letöltés, mint egy weboldal megnyitása. Azonosítót nem küld.
2. **Gyanús alkalmazás bejelentése**, kizárólag a felhasználó kezdeményezésére. Elküldött adatok:
   - a bejelentett alkalmazás csomagneve és megjelenő neve,
   - a telepítés forrása (pl. „Play Áruház”, „APK-fájlból telepítve”),
   - az Adware Scanner verziószáma,
   - a felhasználó által opcionálisan beírt megjegyzés.

   Az IP-címet a szerver **nem tárolja**. Csak egy sózott, visszafejthetetlen kódot ment belőle (SHA-256), hogy a tömeges, automatizált bejelentéseket ki lehessen szűrni.

A bejelentések célja a közös tiltólista bővítése (jogalap: jogos érdek). Megőrzés: a bejelentés elbírálásáig, legfeljebb 2 évig.

## Reklámfigyelő és reklámszűrő (1.1)

- A **reklámfigyelő** a telefon használati statisztikájából ismeri fel a teljes képernyős reklámokat (a felhasználó adja meg a „Használati adatokhoz való hozzáférés” engedélyt). Az észlelések csak a telefonon tárolódnak (események 30 napig, napi összesítők 1 évig).
- A **reklámszűrő** telefonon belüli, csak a DNS-kéréseket vizsgáló VPN. A nem tiltott kéréseket a hálózat saját DNS-szerveréhez vagy – választás esetén – az AdGuard nyilvános DNS-éhez (94.140.14.14) továbbítja. A blokkolt címekből az utolsó 300 és a napi darabszámok a telefonon maradnak.
- A reklámlistákat a telefon közvetlenül a nyilvános forrásokból (GitHub/StevenBlack, AdGuard) tölti le, hetente.
- Ezekből semmi nem kerül a fejlesztőhöz; csak a felhasználó által kezdeményezett bejelentés tartalmazza az adott app reklám-darabszámait.

## Szervizmód

A lista karbantartói a saját fiókjukkal léphetnek be. A belépéshez tartozó tokent az alkalmazás csak a telefonon, privát tárolóban tartja. A szerver ilyenkor a telefon gyártóját és típusát rögzíti (pl. „Samsung SM-A266B”), hogy az elveszett eszközök belépése visszavonható legyen.

## Engedélyek

| Engedély | Mire kell |
|---|---|
| `QUERY_ALL_PACKAGES` | a telepített alkalmazások listázása az ellenőrzéshez |
| `REQUEST_DELETE_PACKAGES` | az eltávolító ablak megnyitása (a rendszer mindig rákérdez) |
| `POST_NOTIFICATIONS` | értesítés tiltott app telepítésekor |
| `INTERNET` | tiltólista letöltése, bejelentés |
| `PACKAGE_USAGE_STATS` | reklámfigyelő: teljes képernyős reklámok felismerése (a felhasználó adja meg) |
| `BIND_VPN_SERVICE` (VPN) | reklámszűrő: reklámcímek kiszűrése a telefonon belül |
| `RECEIVE_BOOT_COMPLETED` | a reklámszűrő újraindítása a telefon bekapcsolása után |
| `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | kérés, hogy a rendszer ne állítsa le a háttérellenőrzést |

Kérdés vagy törlési kérelem: kapcsolat@csakoattila.hu
