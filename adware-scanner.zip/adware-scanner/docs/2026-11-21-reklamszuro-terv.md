# Reklámszűrő és reklámfigyelő – terv (v1.1.0)

Jóváhagyva: 2026-11-21. Az Adware Scanner kiegészítése root nélküli telefonokra.

## Célok
- Reklámok blokkolása az egész telefonon (bekapcsolható, alapból ki).
- Túl sok reklámot mutató appok felismerése, rögzítése, jelzése.
- Az appon kívül reklámot mutató appok (adware) automatikus blokkolása.

## 1. Reklámfigyelő (VPN nélkül is)
- Forrás: `UsageStatsManager` események (felhasználó adja meg a „Használati adatokhoz való hozzáférés” engedélyt).
- Teljes képernyős reklám = ismert reklám-SDK képernyő (`AdSignatures`), a szerverlistából bővíthető.
- **Appon belüli:** napi küszöb (alap 15) felett naponta egy figyelmeztetés.
- **Appon kívüli:** a reklám előtt másik app / kezdőképernyő volt előtérben, az app saját nem-reklám képernyője nélkül → azonnali értesítés; ha a VPN fut és az automatikus blokk be van kapcsolva → az app blokkolása.
- „Megjelenítés más appok felett” engedély jelzése (csak tájékoztató).
- Tárolás: helyi SQLite, események 30 nap, napi összesítők 1 év. Szerverre csak a felhasználó bejelentése megy (automatikusan kitöltött statisztikával).

## 2. VPN-es DNS-szűrő
- Helyi `VpnService`, csak a DNS-forgalom (virtuális DNS: 10.111.222.2/32) megy rajta keresztül.
- Blokkolt cím → NXDOMAIN; egyéb → továbbítás a hálózat saját DNS-ére (vagy AdGuard DNS 94.140.14.14).
- App-hozzárendelés: `getConnectionOwnerUid` (Android 10+).
- Listák: beépített alaplista (+ a fordításkor letöltött StevenBlack-lista), hetente frissítés közvetlenül a GitHubról; opcionális AdGuard DNS-szűrő. Hibás/sikertelen letöltés esetén marad az előző.
- App blokkolása: az app minden DNS-kérése NXDOMAIN.
- Kivételek: kizárt appok (banki appok első bekapcsoláskor javasolva), engedélyezett címek, „Legutóbb blokkolt címek” napló.
- Figyelmeztetés: Privát DNS (szigorú mód) megkerüli a szűrést.
- Újraindítás után automatikus indulás (ha be volt kapcsolva és van VPN-engedély).

## 3. Felület, értesítések
- Új „Reklámok” fül: kapcsoló + mai számok, figyelmeztető kártyák, appok rangsora (ma / 7 / 30 nap), app részletei és teendők, beállítások.
- Állapot fül: összefoglaló sor.
- Értesítések: azonnali (appon kívüli reklám), napi (küszöb felett), heti összesítő (kikapcsolható).

## Korlátok (a felhasználónak is jelezve)
- Állandó értesítés + kulcs ikon, mellette nem futhat más VPN.
- YouTube-reklámok nem szűrhetők; Privát DNS / Chrome „Biztonságos DNS” megkerülheti.
- Android 8–9: blokkolás van, appokra bontás nincs.
- Lebegő (overlay) reklámok nem látszanak a használati statisztikában.
